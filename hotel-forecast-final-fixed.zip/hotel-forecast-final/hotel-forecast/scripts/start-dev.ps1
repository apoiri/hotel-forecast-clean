# Script de démarrage rapide pour Windows
# Démarre l'application en mode développement

Write-Host "🏨 Démarrage de l'Application de Prévision Hôtelière" -ForegroundColor Green
Write-Host ""

# Vérifier si Node.js est installé
try {
    $nodeVersion = node --version
    Write-Host "✅ Node.js détecté: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Node.js n'est pas installé. Veuillez l'installer depuis https://nodejs.org" -ForegroundColor Red
    exit 1
}

# Vérifier si les dépendances sont installées
if (-not (Test-Path "node_modules")) {
    Write-Host "📦 Installation des dépendances..." -ForegroundColor Yellow
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ Erreur lors de l'installation des dépendances" -ForegroundColor Red
        exit 1
    }
}

# Vérifier la configuration Supabase
if (-not (Test-Path ".env.local")) {
    Write-Host "⚠️  Fichier .env.local manquant" -ForegroundColor Yellow
    Write-Host "📝 Copiez env.example vers .env.local et configurez vos clés Supabase" -ForegroundColor Yellow
    Write-Host ""
}

# Démarrer l'application
Write-Host "🚀 Démarrage du serveur de développement..." -ForegroundColor Green
Write-Host "📱 L'application sera disponible sur: http://localhost:3000" -ForegroundColor Cyan
Write-Host ""

npm run dev

