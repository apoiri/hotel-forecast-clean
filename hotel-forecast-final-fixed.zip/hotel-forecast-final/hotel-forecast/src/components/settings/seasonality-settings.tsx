'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { toast } from 'sonner'

const MONTHS = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
]

export function SeasonalitySettings() {
  const [seasonalityData, setSeasonalityData] = useState<Record<number, { occ: number; adr: number }>>({})
  const [isEditing, setIsEditing] = useState(false)
  
  const supabase = createClient()
  const queryClient = useQueryClient()

  // Fetch seasonality data
  const { data: seasonality } = useQuery({
    queryKey: ['seasonality'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('seasonality')
        .select('*')
        .order('month')
      
      if (error) throw error
      return data
    }
  })

  // Update local state when data changes
  useEffect(() => {
    if (seasonality) {
      const data: Record<number, { occ: number; adr: number }> = {}
      seasonality.forEach(item => {
        data[item.month] = {
          occ: Number(item.occ_index),
          adr: Number(item.adr_index)
        }
      })
      setSeasonalityData(data)
    }
  }, [seasonality])

  // Save seasonality
  const saveSeasonalityMutation = useMutation({
    mutationFn: async (data: Record<number, { occ: number; adr: number }>) => {
      const updates = Object.entries(data).map(([month, values]) => ({
        month: parseInt(month),
        occ_index: values.occ,
        adr_index: values.adr
      }))

      const { error } = await supabase
        .from('seasonality')
        .upsert(updates, { onConflict: 'hotel_id,month' })
      
      if (error) throw error
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['seasonality'] })
      toast.success('Coefficients de saisonnalité sauvegardés')
      setIsEditing(false)
    },
    onError: (error) => {
      toast.error('Erreur lors de la sauvegarde: ' + error.message)
    }
  })

  const handleSave = () => {
    saveSeasonalityMutation.mutate(seasonalityData)
  }

  const handleOccChange = (month: number, value: string) => {
    setSeasonalityData(prev => ({
      ...prev,
      [month]: {
        ...prev[month],
        occ: parseFloat(value) || 1
      }
    }))
    setIsEditing(true)
  }

  const handleAdrChange = (month: number, value: string) => {
    setSeasonalityData(prev => ({
      ...prev,
      [month]: {
        ...prev[month],
        adr: parseFloat(value) || 1
      }
    }))
    setIsEditing(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Coefficients de saisonnalité</h2>
          <p className="text-gray-600">Ajustez les coefficients saisonniers pour l'occupation et l'ADR</p>
        </div>
        {isEditing && (
          <Button onClick={handleSave} disabled={saveSeasonalityMutation.isPending}>
            Sauvegarder
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Coefficients mensuels</CardTitle>
          <CardDescription>
            Multiplicateurs appliqués aux baselines. 1.0 = normal, &gt;1.0 = hausse, &lt;1.0 = baisse
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Mois</TableHead>
                <TableHead>Occupation</TableHead>
                <TableHead>ADR</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {MONTHS.map((month, index) => (
                <TableRow key={index + 1}>
                  <TableCell className="font-medium">{month}</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      value={seasonalityData[index + 1]?.occ || 1}
                      onChange={(e) => handleOccChange(index + 1, e.target.value)}
                      className="w-24"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      value={seasonalityData[index + 1]?.adr || 1}
                      onChange={(e) => handleAdrChange(index + 1, e.target.value)}
                      className="w-24"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
