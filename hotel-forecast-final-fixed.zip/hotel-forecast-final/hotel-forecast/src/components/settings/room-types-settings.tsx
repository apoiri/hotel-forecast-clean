'use client'

import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Plus, Edit, Trash2 } from 'lucide-react'
import { toast } from 'sonner'

export function RoomTypesSettings() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingRoomType, setEditingRoomType] = useState<any>(null)
  const [formData, setFormData] = useState({
    code: '',
    label: '',
    base_adr: 0,
    rooms_count: 0,
    sort_order: 0
  })
  
  const supabase = createClient()
  const queryClient = useQueryClient()

  // Fetch room types
  const { data: roomTypes } = useQuery({
    queryKey: ['room-types'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('room_types')
        .select('*')
        .eq('is_active', true)
        .order('sort_order')
      
      if (error) throw error
      return data
    }
  })

  // Create/Update room type
  const saveRoomTypeMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      if (editingRoomType) {
        const { error } = await supabase
          .from('room_types')
          .update(data)
          .eq('id', editingRoomType.id)
        
        if (error) throw error
      } else {
        const { error } = await supabase
          .from('room_types')
          .insert(data)
        
        if (error) throw error
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['room-types'] })
      toast.success(editingRoomType ? 'Type de chambre mis à jour' : 'Type de chambre créé')
      setIsDialogOpen(false)
      setEditingRoomType(null)
      setFormData({ code: '', label: '', base_adr: 0, rooms_count: 0, sort_order: 0 })
    },
    onError: (error) => {
      toast.error('Erreur: ' + error.message)
    }
  })

  // Delete room type
  const deleteRoomTypeMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('room_types')
        .update({ is_active: false })
        .eq('id', id)
      
      if (error) throw error
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['room-types'] })
      toast.success('Type de chambre supprimé')
    },
    onError: (error) => {
      toast.error('Erreur: ' + error.message)
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    saveRoomTypeMutation.mutate(formData)
  }

  const handleEdit = (roomType: any) => {
    setEditingRoomType(roomType)
    setFormData({
      code: roomType.code,
      label: roomType.label,
      base_adr: roomType.base_adr,
      rooms_count: roomType.rooms_count,
      sort_order: roomType.sort_order
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce type de chambre ?')) {
      deleteRoomTypeMutation.mutate(id)
    }
  }

  const handleNew = () => {
    setEditingRoomType(null)
    setFormData({ code: '', label: '', base_adr: 0, rooms_count: 0, sort_order: 0 })
    setIsDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Types de chambres</h2>
          <p className="text-gray-600">Gérez les types de chambres et leurs prix de base</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleNew}>
              <Plus className="h-4 w-4 mr-2" />
              Nouveau type
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingRoomType ? 'Modifier le type de chambre' : 'Nouveau type de chambre'}
              </DialogTitle>
              <DialogDescription>
                Définissez les caractéristiques du type de chambre
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="code">Code</Label>
                  <Input
                    id="code"
                    value={formData.code}
                    onChange={(e) => setFormData(prev => ({ ...prev, code: e.target.value }))}
                    placeholder="ex: SUITE_EXEC"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="label">Libellé</Label>
                  <Input
                    id="label"
                    value={formData.label}
                    onChange={(e) => setFormData(prev => ({ ...prev, label: e.target.value }))}
                    placeholder="ex: Suite exécutive"
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="base_adr">ADR de base (CAD)</Label>
                  <Input
                    id="base_adr"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.base_adr}
                    onChange={(e) => setFormData(prev => ({ ...prev, base_adr: parseFloat(e.target.value) || 0 }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="rooms_count">Nombre de chambres</Label>
                  <Input
                    id="rooms_count"
                    type="number"
                    min="0"
                    value={formData.rooms_count}
                    onChange={(e) => setFormData(prev => ({ ...prev, rooms_count: parseInt(e.target.value) || 0 }))}
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="sort_order">Ordre d'affichage</Label>
                <Input
                  id="sort_order"
                  type="number"
                  min="0"
                  value={formData.sort_order}
                  onChange={(e) => setFormData(prev => ({ ...prev, sort_order: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit" disabled={saveRoomTypeMutation.isPending}>
                  {editingRoomType ? 'Mettre à jour' : 'Créer'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Types de chambres actifs</CardTitle>
          <CardDescription>Liste des types de chambres configurés</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Libellé</TableHead>
                <TableHead>ADR de base</TableHead>
                <TableHead>Chambres</TableHead>
                <TableHead>Ordre</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {roomTypes?.map((roomType) => (
                <TableRow key={roomType.id}>
                  <TableCell className="font-mono">{roomType.code}</TableCell>
                  <TableCell>{roomType.label}</TableCell>
                  <TableCell>${roomType.base_adr}</TableCell>
                  <TableCell>{roomType.rooms_count}</TableCell>
                  <TableCell>{roomType.sort_order}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(roomType)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(roomType.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
