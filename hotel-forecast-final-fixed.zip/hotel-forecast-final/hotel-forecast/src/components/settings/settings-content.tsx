'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { BaselineSettings } from './baseline-settings'
import { SeasonalitySettings } from './seasonality-settings'
import { RoomTypesSettings } from './room-types-settings'
import { EventsSettings } from './events-settings'

export function SettingsContent() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Paramètres</h1>
        <p className="text-gray-600">Configurez les paramètres de base pour vos prévisions</p>
      </div>

      <Tabs defaultValue="baseline" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="baseline">Baselines</TabsTrigger>
          <TabsTrigger value="seasonality">Saisonnalité</TabsTrigger>
          <TabsTrigger value="room-types">Types de chambres</TabsTrigger>
          <TabsTrigger value="events">Événements</TabsTrigger>
        </TabsList>

        <TabsContent value="baseline">
          <BaselineSettings />
        </TabsContent>

        <TabsContent value="seasonality">
          <SeasonalitySettings />
        </TabsContent>

        <TabsContent value="room-types">
          <RoomTypesSettings />
        </TabsContent>

        <TabsContent value="events">
          <EventsSettings />
        </TabsContent>
      </Tabs>
    </div>
  )
}
