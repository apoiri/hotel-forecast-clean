'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { toast } from 'sonner'

const MONTHS = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
]

export function BaselineSettings() {
  const [selectedYear, setSelectedYear] = useState(2025)
  const [occupancyData, setOccupancyData] = useState<Record<number, number>>({})
  const [adrData, setAdrData] = useState<Record<number, number>>({})
  const [isEditing, setIsEditing] = useState(false)
  
  const supabase = createClient()
  const queryClient = useQueryClient()

  // Fetch occupancy baseline
  const { data: occupancyBaseline } = useQuery({
    queryKey: ['occupancy-baseline', selectedYear],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('occupancy_baseline')
        .select('*')
        .eq('year', selectedYear)
        .order('month')
      
      if (error) throw error
      return data
    }
  })

  // Fetch ADR baseline
  const { data: adrBaseline } = useQuery({
    queryKey: ['adr-baseline', selectedYear],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('adr_baseline')
        .select('*')
        .eq('year', selectedYear)
        .order('month')
      
      if (error) throw error
      return data
    }
  })

  // Update local state when data changes
  useEffect(() => {
    if (occupancyBaseline) {
      const data: Record<number, number> = {}
      occupancyBaseline.forEach(item => {
        data[item.month] = Number(item.base_occ_pct)
      })
      setOccupancyData(data)
    }
  }, [occupancyBaseline])

  useEffect(() => {
    if (adrBaseline) {
      const data: Record<number, number> = {}
      adrBaseline.forEach(item => {
        data[item.month] = Number(item.base_adr)
      })
      setAdrData(data)
    }
  }, [adrBaseline])

  // Save occupancy baseline
  const saveOccupancyMutation = useMutation({
    mutationFn: async (data: Record<number, number>) => {
      const updates = Object.entries(data).map(([month, value]) => ({
        year: selectedYear,
        month: parseInt(month),
        base_occ_pct: value
      }))

      const { error } = await supabase
        .from('occupancy_baseline')
        .upsert(updates, { onConflict: 'hotel_id,year,month' })
      
      if (error) throw error
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['occupancy-baseline'] })
      toast.success('Baseline d\'occupation sauvegardée')
      setIsEditing(false)
    },
    onError: (error) => {
      toast.error('Erreur lors de la sauvegarde: ' + error.message)
    }
  })

  // Save ADR baseline
  const saveAdrMutation = useMutation({
    mutationFn: async (data: Record<number, number>) => {
      const updates = Object.entries(data).map(([month, value]) => ({
        year: selectedYear,
        month: parseInt(month),
        base_adr: value
      }))

      const { error } = await supabase
        .from('adr_baseline')
        .upsert(updates, { onConflict: 'hotel_id,year,month' })
      
      if (error) throw error
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adr-baseline'] })
      toast.success('Baseline ADR sauvegardée')
      setIsEditing(false)
    },
    onError: (error) => {
      toast.error('Erreur lors de la sauvegarde: ' + error.message)
    }
  })

  const handleSave = () => {
    saveOccupancyMutation.mutate(occupancyData)
    saveAdrMutation.mutate(adrData)
  }

  const handleOccupancyChange = (month: number, value: string) => {
    setOccupancyData(prev => ({
      ...prev,
      [month]: parseFloat(value) || 0
    }))
    setIsEditing(true)
  }

  const handleAdrChange = (month: number, value: string) => {
    setAdrData(prev => ({
      ...prev,
      [month]: parseFloat(value) || 0
    }))
    setIsEditing(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Baselines de référence</h2>
          <p className="text-gray-600">Définissez les taux d'occupation et ADR de base par mois</p>
        </div>
        <div className="flex space-x-4">
          <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(parseInt(value))}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2025">2025</SelectItem>
              <SelectItem value="2026">2026</SelectItem>
            </SelectContent>
          </Select>
          {isEditing && (
            <Button onClick={handleSave} disabled={saveOccupancyMutation.isPending || saveAdrMutation.isPending}>
              Sauvegarder
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Occupancy Baseline */}
        <Card>
          <CardHeader>
            <CardTitle>Taux d'occupation (%)</CardTitle>
            <CardDescription>Pourcentage d'occupation de base par mois</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Mois</TableHead>
                  <TableHead>Taux (%)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {MONTHS.map((month, index) => (
                  <TableRow key={index + 1}>
                    <TableCell>{month}</TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        step="0.01"
                        value={occupancyData[index + 1] ? (occupancyData[index + 1] * 100).toFixed(1) : ''}
                        onChange={(e) => handleOccupancyChange(index + 1, (parseFloat(e.target.value) / 100).toString())}
                        className="w-24"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* ADR Baseline */}
        <Card>
          <CardHeader>
            <CardTitle>ADR de base (CAD)</CardTitle>
            <CardDescription>Prix moyen par nuit de base par mois</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Mois</TableHead>
                  <TableHead>ADR (CAD)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {MONTHS.map((month, index) => (
                  <TableRow key={index + 1}>
                    <TableCell>{month}</TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        value={adrData[index + 1] || ''}
                        onChange={(e) => handleAdrChange(index + 1, e.target.value)}
                        className="w-24"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
