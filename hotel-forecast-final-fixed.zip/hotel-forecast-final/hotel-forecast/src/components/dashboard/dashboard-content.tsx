'use client'

import { useState, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { TrendingUp, TrendingDown, DollarSign, Users, Calendar } from 'lucide-react'

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658']

export function DashboardContent() {
  const [selectedYear, setSelectedYear] = useState(2025)
  const [selectedScenario, setSelectedScenario] = useState<string>('')
  const supabase = createClient()

  // Fetch scenarios
  const { data: scenarios } = useQuery({
    queryKey: ['scenarios'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('scenarios')
        .select('id, name, visibility')
        .order('created_at', { ascending: false })
      
      if (error) throw error
      return data
    }
  })

  // Fetch forecast results
  const { data: forecastResults, isLoading } = useQuery({
    queryKey: ['forecast-results', selectedScenario, selectedYear],
    queryFn: async () => {
      if (!selectedScenario) return null
      
      const { data, error } = await supabase
        .from('forecast_results')
        .select('*')
        .eq('scenario_id', selectedScenario)
        .eq('year', selectedYear)
        .order('month')
      
      if (error) throw error
      return data
    },
    enabled: !!selectedScenario
  })

  // Fetch forecast results by type
  const { data: forecastResultsByType } = useQuery({
    queryKey: ['forecast-results-by-type', selectedScenario, selectedYear],
    queryFn: async () => {
      if (!selectedScenario) return null
      
      const { data, error } = await supabase
        .from('forecast_results_by_type')
        .select(`
          *,
          room_types!inner(label, code)
        `)
        .eq('scenario_id', selectedScenario)
        .eq('year', selectedYear)
        .order('month')
      
      if (error) throw error
      return data
    },
    enabled: !!selectedScenario
  })

  // Fetch segments data
  const { data: segments } = useQuery({
    queryKey: ['segments'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('segments')
        .select('*')
        .order('code')
      
      if (error) throw error
      return data
    }
  })

  // Set default scenario
  useEffect(() => {
    if (scenarios && scenarios.length > 0 && !selectedScenario) {
      setSelectedScenario(scenarios[0].id)
    }
  }, [scenarios, selectedScenario])

  // Calculate KPIs
  const kpis = forecastResults ? {
    totalRevenue: forecastResults.reduce((sum, r) => sum + r.room_revenue, 0),
    avgOccupancy: forecastResults.reduce((sum, r) => sum + r.occ_pct, 0) / forecastResults.length,
    avgADR: forecastResults.reduce((sum, r) => sum + r.adr, 0) / forecastResults.length,
    avgRevPAR: forecastResults.reduce((sum, r) => sum + r.revpar, 0) / forecastResults.length,
  } : null

  // Prepare chart data
  const monthlyData = forecastResults?.map(r => ({
    month: new Date(selectedYear, r.month - 1).toLocaleDateString('fr-FR', { month: 'short' }),
    revenue: Math.round(r.room_revenue),
    occupancy: Math.round(r.occ_pct * 100),
    adr: Math.round(r.adr),
    revpar: Math.round(r.revpar)
  })) || []

  // Prepare segment data (mock for now - would need actual segment breakdown)
  const segmentData = segments?.map((segment, index) => ({
    name: segment.label,
    value: Math.round((kpis?.totalRevenue || 0) * (0.2 + Math.random() * 0.1)), // Mock data
    color: COLORS[index % COLORS.length]
  })) || []

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Vue d'ensemble des prévisions de ventes</p>
        </div>
        <div className="flex space-x-4">
          <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(parseInt(value))}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2025">2025</SelectItem>
              <SelectItem value="2026">2026</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedScenario} onValueChange={setSelectedScenario}>
            <SelectTrigger className="w-64">
              <SelectValue placeholder="Sélectionner un scénario" />
            </SelectTrigger>
            <SelectContent>
              {scenarios?.map((scenario) => (
                <SelectItem key={scenario.id} value={scenario.id}>
                  {scenario.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* KPIs */}
      {kpis && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Revenus totaux</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${kpis.totalRevenue.toLocaleString('fr-CA')}
              </div>
              <p className="text-xs text-muted-foreground">
                CAD pour {selectedYear}
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Taux d'occupation moyen</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {Math.round(kpis.avgOccupancy * 100)}%
              </div>
              <p className="text-xs text-muted-foreground">
                Moyenne annuelle
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ADR moyen</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${Math.round(kpis.avgADR)}
              </div>
              <p className="text-xs text-muted-foreground">
                Prix moyen par nuit
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">RevPAR moyen</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${Math.round(kpis.avgRevPAR)}
              </div>
              <p className="text-xs text-muted-foreground">
                Revenu par chambre disponible
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Revenue Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Revenus mensuels</CardTitle>
            <CardDescription>Évolution des revenus par mois</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => [`$${value.toLocaleString('fr-CA')}`, 'Revenus']} />
                <Bar dataKey="revenue" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Segment Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Répartition par origine</CardTitle>
            <CardDescription>Part des revenus par segment de clientèle</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={segmentData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${((percent || 0) * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {segmentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`$${value.toLocaleString('fr-CA')}`, 'Revenus']} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Occupancy and ADR Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Taux d'occupation</CardTitle>
            <CardDescription>Évolution mensuelle du taux d'occupation</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value}%`, 'Occupation']} />
                <Bar dataKey="occupancy" fill="#10B981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>ADR et RevPAR</CardTitle>
            <CardDescription>Prix moyen et revenu par chambre</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => [`$${value}`, 'Prix']} />
                <Bar dataKey="adr" fill="#F59E0B" name="ADR" />
                <Bar dataKey="revpar" fill="#EF4444" name="RevPAR" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
