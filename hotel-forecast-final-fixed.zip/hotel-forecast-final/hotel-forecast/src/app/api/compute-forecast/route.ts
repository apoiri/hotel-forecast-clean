import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { hotelId, scenarioId, year } = body

    if (!hotelId || !scenarioId || !year) {
      return NextResponse.json({ error: 'Missing required parameters' }, { status: 400 })
    }

    // Call the Edge Function
    const { data, error } = await supabase.functions.invoke('compute_forecast', {
      body: { hotelId, scenarioId, year }
    })

    if (error) {
      console.error('Edge function error:', error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error('API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
