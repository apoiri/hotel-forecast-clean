import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export default function AuthCodeError() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-red-600">Erreur de connexion</CardTitle>
          <CardDescription>
            Il y a eu un problème avec votre lien de connexion
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-sm text-gray-600 mb-4">
            Le lien de connexion a expiré ou est invalide. Veuillez demander un nouveau lien.
          </p>
          <Link href="/auth">
            <Button className="w-full">
              Retour à la connexion
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  )
}
