/**
 * Utility functions for hotel forecast calculations
 */

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('fr-CA', {
    style: 'currency',
    currency: 'CAD'
  }).format(amount)
}

export function calculateOccupancy(roomsSold: number, roomsAvailable: number, days: number): number {
  if (roomsAvailable === 0 || days === 0) return 0
  return Math.min(1, Math.max(0, roomsSold / (roomsAvailable * days)))
}

export function calculateRevPAR(revenue: number, roomsAvailable: number, days: number): number {
  if (roomsAvailable === 0 || days === 0) return 0
  return revenue / (roomsAvailable * days)
}

export function calculateADR(revenue: number, roomsSold: number): number {
  if (roomsSold === 0) return 0
  return revenue / roomsSold
}

export function daysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate()
}

export function calculateEventOverlap(
  eventStart: Date,
  eventEnd: Date,
  monthStart: Date,
  monthEnd: Date
): number {
  const overlapStart = eventStart > monthStart ? eventStart : monthStart
  const overlapEnd = eventEnd < monthEnd ? eventEnd : monthEnd
  
  if (overlapStart >= overlapEnd) return 0
  
  return Math.max(0, (overlapEnd.getTime() - overlapStart.getTime()) / (1000 * 3600 * 24) + 1)
}

export function applySeasonality(baseValue: number, seasonalityIndex: number): number {
  return baseValue * seasonalityIndex
}

export function applyUplift(baseValue: number, upliftPercent: number): number {
  return baseValue * (1 + upliftPercent)
}

export function roundToDecimals(value: number, decimals: number = 2): number {
  return Math.round(value * Math.pow(10, decimals)) / Math.pow(10, decimals)
}

