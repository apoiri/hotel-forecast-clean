-- ─────────────────────────────────────────────────────────────────────────────
-- SEED DATA - HOTEL FORECAST APPLICATION
-- ─────────────────────────────────────────────────────────────────────────────

-- Insère les segments de clientèle
insert into public.segments(code,label) values
('CAN_FR','Canada francophone'),
('CAN_EN','Canada anglophone'),
('USA','États-Unis'),
('EUR','Europe'),
('LATAM','Amérique du Sud'),
('AFR','Afrique'),
('ASIA','Asie');

-- Crée une organisation et un hôtel de démonstration
insert into public.organizations(name) values ('Hotel Edu Org') returning id;
-- Note: Remplacer '{{ORG_ID}}' par l'ID réel de l'organisation créée

-- Insère l'hôtel de démonstration
insert into public.hotels(org_id, name, city, rooms_total) 
values ('{{ORG_ID}}', 'Hôtel de la Promenade', 'Ottawa', 100) 
returning id;
-- Note: Remplacer '{{HOTEL_ID}}' par l'ID réel de l'hôtel créé

-- Saisonnalité par défaut (1.0 partout - à ajuster selon les besoins)
insert into public.seasonality(hotel_id,month,occ_index,adr_index)
select '{{HOTEL_ID}}', m, 1.0, 1.0 from generate_series(1,12) g(m);

-- Baselines d'occupation pour 2025 (exemple réaliste pour Ottawa)
insert into public.occupancy_baseline(hotel_id,year,month,base_occ_pct)
select '{{HOTEL_ID}}', 2025, m, case
  when m in (6,7,8,9) then 0.78  -- Été: haute saison
  when m in (5,10) then 0.65     -- Printemps/Automne: saison moyenne
  when m in (11,12,1,2) then 0.55 -- Hiver: basse saison
  else 0.60 end                  -- Mars, Avril: transition
from generate_series(1,12) g(m);

-- Baselines ADR pour 2025 (prix moyens en CAD)
insert into public.adr_baseline(hotel_id,year,month,base_adr)
select '{{HOTEL_ID}}', 2025, m, case
  when m in (6,7,8,9) then 215   -- Été: prix élevés
  when m in (5,10) then 190      -- Printemps/Automne: prix moyens
  else 165 end                   -- Hiver: prix réduits
from generate_series(1,12) g(m);

-- Paramètres de forecast par défaut (mix segments)
insert into public.forecast_params(hotel_id,name,segment_share)
values ('{{HOTEL_ID}}','Par défaut', '{"CAN_FR":0.25,"CAN_EN":0.30,"USA":0.20,"EUR":0.15,"LATAM":0.03,"AFR":0.02,"ASIA":0.05}');

-- Types de chambres avec capacités et prix de base (CAD)
insert into public.room_types (hotel_id, code, label, base_adr, rooms_count, sort_order) values
('{{HOTEL_ID}}','SUITE_EXEC','Suites exécutives', 600.00, 5, 10),
('{{HOTEL_ID}}','SUITE_SEN','Suites séniors',    450.00, 5, 20),
('{{HOTEL_ID}}','SUITE_JUN','Suites juniors',    350.00, 5, 30),
('{{HOTEL_ID}}','DLX','Chambres de luxe',        300.00, 20, 40),
('{{HOTEL_ID}}','CLS','Chambres classiques',     250.00, 65, 50);

-- Ajustements de marché par défaut (0% pour tous les mois 2025)
insert into public.room_type_monthly_pricing (hotel_id, room_type_id, year, month, market_adj_pct)
select '{{HOTEL_ID}}', rt.id, 2025, m, 0
from public.room_types rt
cross join generate_series(1,12) g(m)
where rt.hotel_id='{{HOTEL_ID}}';

-- Événements de démonstration
insert into public.demand_events(hotel_id, name, start_date, end_date, occ_uplift_pct, adr_uplift_pct) values
('{{HOTEL_ID}}', 'Congrès médical', '2025-03-15', '2025-03-18', 0.15, 0.10),
('{{HOTEL_ID}}', 'Festival d\'été', '2025-07-10', '2025-07-15', 0.20, 0.15),
('{{HOTEL_ID}}', 'Conférence tech', '2025-09-20', '2025-09-22', 0.12, 0.08);

-- Scénario de base
insert into public.scenarios(hotel_id, params_id, name, adjustments, visibility)
select 
  '{{HOTEL_ID}}',
  fp.id,
  'Scénario de base',
  '{"global": {"occ_shift_pct":0, "adr_shift_pct":0, "blocked_rooms":0}, "segments": {}}',
  'org'
from public.forecast_params fp
where fp.hotel_id = '{{HOTEL_ID}}' and fp.name = 'Par défaut';
