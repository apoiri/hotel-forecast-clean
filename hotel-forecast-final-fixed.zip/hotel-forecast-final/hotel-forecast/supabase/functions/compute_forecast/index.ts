// supabase/functions/compute_forecast/index.ts
// deno-lint-ignore-file no-explicit-any
import 'jsr:@supabase/functions-js/edge-runtime.d.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { z } from 'https://esm.sh/zod@3'

const InputSchema = z.object({
  hotelId: z.string().uuid(),
  scenarioId: z.string().uuid(),
  year: z.number().int().min(2000).max(2100)
})

type Row<T> = T extends Promise<infer U> ? U : never

function daysInMonth(year: number, month: number) {
  return new Date(year, month, 0).getDate()
}

Deno.serve(async (req) => {
  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseAnon = Deno.env.get('SUPABASE_ANON_KEY')! // used for getUser
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')! // write results

    const authClient = createClient(supabaseUrl, supabaseAnon, {
      global: { headers: { Authorization: req.headers.get('Authorization')! } }
    })
    const serviceClient = createClient(supabaseUrl, serviceRoleKey)

    const body = await req.json()
    const { hotelId, scenarioId, year } = InputSchema.parse(body)

    // Auth check: user is logged in
    const { data: { user }, error: userErr } = await authClient.auth.getUser()
    if (userErr || !user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 })

    // Check membership (user ∈ hotel)
    const { data: me, error: meErr } = await authClient
      .from('profiles')
      .select('hotel_id')
      .eq('user_id', user.id)
      .single()
    if (meErr || !me || me.hotel_id !== hotelId) {
      return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403 })
    }

    // Load scenario
    const { data: scenario, error: scErr } = await authClient
      .from('scenarios')
      .select('id, hotel_id, params_id, adjustments')
      .eq('id', scenarioId).single()
    if (scErr || !scenario || scenario.hotel_id !== hotelId) {
      return new Response(JSON.stringify({ error: 'Scenario not found' }), { status: 404 })
    }

    // Load params (segment share; useful for charts; calc agrégé pour MVP)
    const { data: params, error: pErr } = await authClient
      .from('forecast_params')
      .select('segment_share')
      .eq('id', scenario.params_id).single()
    if (pErr || !params) {
      return new Response(JSON.stringify({ error: 'Params not found' }), { status: 404 })
    }

    // Baselines (occ, adr)
    const { data: occBase, error: occErr } = await authClient
      .from('occupancy_baseline')
      .select('month, base_occ_pct')
      .eq('hotel_id', hotelId)
      .eq('year', year)
      .order('month')
    if (occErr || !occBase?.length) {
      return new Response(JSON.stringify({ error: 'No occupancy baseline' }), { status: 422 })
    }

    const { data: adrBase, error: adrErr } = await authClient
      .from('adr_baseline')
      .select('month, base_adr')
      .eq('hotel_id', hotelId)
      .eq('year', year)
      .order('month')
    if (adrErr || !adrBase?.length) {
      return new Response(JSON.stringify({ error: 'No ADR baseline' }), { status: 422 })
    }

    // Seasonality
    const { data: season, error: seasErr } = await authClient
      .from('seasonality')
      .select('month, occ_index, adr_index')
      .eq('hotel_id', hotelId)
      .order('month')
    if (seasErr || !season?.length) {
      return new Response(JSON.stringify({ error: 'No seasonality' }), { status: 422 })
    }

    // Demand events (on prorate by overlap days)
    const { data: events, error: evErr } = await authClient
      .from('demand_events')
      .select('start_date, end_date, occ_uplift_pct, adr_uplift_pct, locked')
      .eq('hotel_id', hotelId)
    if (evErr) {
      return new Response(JSON.stringify({ error: 'Events load error' }), { status: 500 })
    }

    // Room types & monthly pricing
    const { data: roomTypes, error: rtErr } = await authClient
      .from('room_types')
      .select('id, base_adr, rooms_count, is_active')
      .eq('hotel_id', hotelId)
      .eq('is_active', true)
    if (rtErr || !roomTypes?.length) {
      return new Response(JSON.stringify({ error: 'No active room types' }), { status: 422 })
    }

    const { data: pricing, error: prErr } = await authClient
      .from('room_type_monthly_pricing')
      .select('room_type_id, year, month, market_adj_pct, override_adr')
      .eq('hotel_id', hotelId)
      .eq('year', year)
    if (prErr) {
      return new Response(JSON.stringify({ error: 'Pricing load error' }), { status: 500 })
    }

    const occMap = new Map(occBase.map(r => [r.month, Number(r.base_occ_pct)]))
    const adrMap = new Map(adrBase.map(r => [r.month, Number(r.base_adr)]))
    const seasMap = new Map(season.map(r => [r.month, { occ: Number(r.occ_index), adr: Number(r.adr_index) }]))

    // Scenario adjustments (global)
    const globalAdj = (scenario.adjustments?.global ?? {}) as {
      occ_shift_pct?: number
      adr_shift_pct?: number
      blocked_rooms?: number
    }
    const occShift = Number(globalAdj.occ_shift_pct ?? 0)
    const adrShift = Number(globalAdj.adr_shift_pct ?? 0)
    const blockedRooms = Math.max(0, Number(globalAdj.blocked_rooms ?? 0))

    // Helper: compute monthly overlap uplift for events
    function eventUpliftsForMonth(mYear: number, m: number) {
      if (!events?.length) return { occUplift: 0, adrUplift: 0 }
      const start = new Date(mYear, m - 1, 1)
      const end = new Date(mYear, m, 0) // last day
      const totalDays = end.getDate()
      let occ = 0, adr = 0
      for (const e of events) {
        const s = new Date(e.start_date)
        const ed = new Date(e.end_date)
        const overlapStart = s > start ? s : start
        const overlapEnd = ed < end ? ed : end
        const overlap = Math.max(0, (overlapEnd.getTime() - overlapStart.getTime()) / (1000*3600*24) + 1)
        if (overlap > 0) {
          const weight = overlap / totalDays
          occ += Number(e.occ_uplift_pct ?? 0) * weight
          adr += Number(e.adr_uplift_pct ?? 0) * weight
        }
      }
      return { occUplift: occ, adrUplift: adr }
    }

    // Build pricing map per type+month
    const pKey = (rtId: string, m: number) => `${rtId}_${m}`
    const priceMap = new Map<string, { marketAdj: number; override?: number }>()
    for (const p of pricing ?? []) {
      priceMap.set(pKey(p.room_type_id, p.month), { marketAdj: Number(p.market_adj_pct ?? 0), override: p.override_adr == null ? undefined : Number(p.override_adr) })
    }

    // Capacity
    const totalRoomsActive = roomTypes.reduce((acc, r) => acc + Number(r.rooms_count), 0)
    const netRoomsAvailable = Math.max(0, totalRoomsActive - blockedRooms)

    // Per-month results (aggregate)
    const monthsOut: Array<any> = []

    // Compute per type and upsert
    for (let m = 1; m <= 12; m++) {
      const dim = daysInMonth(year, m)
      const occBaseM = (occMap.get(m) ?? 0) * (seasMap.get(m)?.occ ?? 1)
      const { occUplift, adrUplift } = eventUpliftsForMonth(year, m)
      // global adj
      const occFinalFactor = (1 + occUplift) * (1 + occShift)
      const adrBaseM = (adrMap.get(m) ?? 0) * (seasMap.get(m)?.adr ?? 1)
      const adrFinalFactor = (1 + adrUplift) * (1 + adrShift)

      let monthRoomsSold = 0
      let monthRevenue = 0

      for (const rt of roomTypes) {
        const rtRooms = Number(rt.rooms_count)
        const rtAvail = Math.max(0, Math.round(netRoomsAvailable * (rtRooms / totalRoomsActive))) // proportionnel
        // Occ par type = même taux (MVP). Phase 2: élasticités spécifiques par type.
        const occPctType = Math.min(1, Math.max(0, occBaseM * occFinalFactor))
        const sold = Math.round(occPctType * rtAvail * dim)

        // ADR par type
        const overrideObj = priceMap.get(pKey(rt.id, m))
        let adrType = (overrideObj?.override != null)
          ? overrideObj.override
          : ( (rt.base_adr) * (adrBaseM / (adrMap.get(m) || 1)) * adrFinalFactor )

        // market adj sur ADR si pas override
        if (overrideObj?.override == null) {
          const marketAdj = overrideObj?.marketAdj ?? 0
          adrType = adrType * (1 + marketAdj)
        }

        const revenue = sold * adrType
        const revpar = revenue / (rtAvail * dim || 1)

        monthRoomsSold += sold
        monthRevenue += revenue

        // UPSERT by type
        const byTypePayload = {
          hotel_id: hotelId,
          scenario_id: scenarioId,
          room_type_id: rt.id,
          year,
          month: m,
          occ_pct: occPctType,
          rooms_sold: sold,
          adr: adrType,
          revpar: revpar,
          room_revenue: revenue
        }

        const { error: upErr1 } = await serviceClient
          .from('forecast_results_by_type')
          .upsert(byTypePayload, { onConflict: 'scenario_id,room_type_id,year,month' })
        if (upErr1) throw upErr1
      }

      const occPctAgg = monthRoomsSold / (netRoomsAvailable * dim || 1)
      const adrAgg = monthRevenue / (monthRoomsSold || 1)
      const revparAgg = monthRevenue / (netRoomsAvailable * dim || 1)

      // UPSERT aggregate
      const aggPayload = {
        hotel_id: hotelId,
        scenario_id: scenarioId,
        year,
        month: m,
        occ_pct: occPctAgg,
        rooms_sold: monthRoomsSold,
        adr: adrAgg,
        revpar: revparAgg,
        room_revenue: monthRevenue
      }
      const { error: upErr2 } = await serviceClient
        .from('forecast_results')
        .upsert(aggPayload, { onConflict: 'scenario_id,year,month' })
      if (upErr2) throw upErr2

      monthsOut.push({ month: m, occ_pct: occPctAgg, rooms_sold: monthRoomsSold, adr: adrAgg, revpar: revparAgg, room_revenue: monthRevenue })
    }

    // Audit
    await serviceClient.from('audit_log').insert({
      user_id: user.id,
      action: 'compute_forecast',
      entity: 'scenario',
      entity_id: scenarioId,
      payload: { year, months: monthsOut.length }
    })

    return new Response(JSON.stringify({ ok: true, months: monthsOut }), { status: 200 })
  } catch (e) {
    console.error(e)
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 })
  }
})
