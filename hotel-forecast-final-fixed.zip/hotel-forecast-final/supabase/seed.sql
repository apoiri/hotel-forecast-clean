-- Insert default organization
INSERT INTO public.organizations (id, name) VALUES 
('550e8400-e29b-41d4-a716-446655440000', 'Collège la Cité');

-- Insert default hotel
INSERT INTO public.hotels (id, org_id, name, city, timezone, currency, rooms_total) VALUES 
('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', 'Hôtel Collège la Cité', 'Ottawa', 'America/Toronto', 'CAD', 100);

-- Insert default segments
INSERT INTO public.segments (code, label) VALUES 
('LEISURE', 'Loisirs'),
('BUSINESS', 'Affaires'),
('GROUP', 'Groupes'),
('GOVT', 'Gouvernement'),
('OTHER', 'Autres');

-- Insert default room types
INSERT INTO public.room_types (id, hotel_id, code, label, base_adr, rooms_count, is_active, sort_order) VALUES 
('550e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440001', 'STD', 'Chambre Standard', 120.00, 40, true, 1),
('550e8400-e29b-41d4-a716-446655440011', '550e8400-e29b-41d4-a716-446655440001', 'DEL', 'Chambre Deluxe', 150.00, 30, true, 2),
('550e8400-e29b-41d4-a716-446655440012', '550e8400-e29b-41d4-a716-446655440001', 'SUITE', 'Suite', 200.00, 20, true, 3),
('550e8400-e29b-41d4-a716-446655440013', '550e8400-e29b-41d4-a716-446655440001', 'FAM', 'Chambre Familiale', 180.00, 8, true, 4),
('550e8400-e29b-41d4-a716-446655440014', '550e8400-e29b-41d4-a716-446655440001', 'EXEC', 'Chambre Exécutive', 170.00, 2, true, 5);

-- Insert default occupancy baseline for 2025
INSERT INTO public.occupancy_baseline (hotel_id, year, month, base_occ_pct) VALUES 
('550e8400-e29b-41d4-a716-446655440001', 2025, 1, 0.45),
('550e8400-e29b-41d4-a716-446655440001', 2025, 2, 0.50),
('550e8400-e29b-41d4-a716-446655440001', 2025, 3, 0.55),
('550e8400-e29b-41d4-a716-446655440001', 2025, 4, 0.60),
('550e8400-e29b-41d4-a716-446655440001', 2025, 5, 0.65),
('550e8400-e29b-41d4-a716-446655440001', 2025, 6, 0.70),
('550e8400-e29b-41d4-a716-446655440001', 2025, 7, 0.75),
('550e8400-e29b-41d4-a716-446655440001', 2025, 8, 0.80),
('550e8400-e29b-41d4-a716-446655440001', 2025, 9, 0.70),
('550e8400-e29b-41d4-a716-446655440001', 2025, 10, 0.65),
('550e8400-e29b-41d4-a716-446655440001', 2025, 11, 0.60),
('550e8400-e29b-41d4-a716-446655440001', 2025, 12, 0.55);

-- Insert default ADR baseline for 2025
INSERT INTO public.adr_baseline (hotel_id, year, month, base_adr) VALUES 
('550e8400-e29b-41d4-a716-446655440001', 2025, 1, 120.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 2, 125.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 3, 130.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 4, 135.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 5, 140.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 6, 145.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 7, 150.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 8, 155.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 9, 145.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 10, 140.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 11, 135.00),
('550e8400-e29b-41d4-a716-446655440001', 2025, 12, 130.00);

-- Insert default seasonality
INSERT INTO public.seasonality (hotel_id, month, occ_index, adr_index) VALUES 
('550e8400-e29b-41d4-a716-446655440001', 1, 0.8, 0.9),
('550e8400-e29b-41d4-a716-446655440001', 2, 0.85, 0.95),
('550e8400-e29b-41d4-a716-446655440001', 3, 0.9, 1.0),
('550e8400-e29b-41d4-a716-446655440001', 4, 0.95, 1.05),
('550e8400-e29b-41d4-a716-446655440001', 5, 1.0, 1.1),
('550e8400-e29b-41d4-a716-446655440001', 6, 1.1, 1.15),
('550e8400-e29b-41d4-a716-446655440001', 7, 1.2, 1.2),
('550e8400-e29b-41d4-a716-446655440001', 8, 1.25, 1.25),
('550e8400-e29b-41d4-a716-446655440001', 9, 1.1, 1.15),
('550e8400-e29b-41d4-a716-446655440001', 10, 1.0, 1.1),
('550e8400-e29b-41d4-a716-446655440001', 11, 0.95, 1.05),
('550e8400-e29b-41d4-a716-446655440001', 12, 0.9, 1.0);

-- Insert default forecast parameters
INSERT INTO public.forecast_params (id, hotel_id, name, description, segment_share) VALUES 
('550e8400-e29b-41d4-a716-446655440020', '550e8400-e29b-41d4-a716-446655440001', 'Paramètres par défaut', 'Configuration de base pour les prévisions', '{"LEISURE": 0.4, "BUSINESS": 0.35, "GROUP": 0.15, "GOVT": 0.08, "OTHER": 0.02}');