import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Create Supabase client with service role key
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get request body
    const { scenarioId, byType = false } = await req.json()

    if (!scenarioId) {
      return new Response(
        JSON.stringify({ error: 'Missing scenarioId parameter' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Fetch scenario data
    const { data: scenario, error: scenarioError } = await supabaseClient
      .from('scenarios')
      .select(`
        *,
        forecast_params (*)
      `)
      .eq('id', scenarioId)
      .single()

    if (scenarioError || !scenario) {
      return new Response(
        JSON.stringify({ error: 'Scenario not found' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    let csvData = ''
    let filename = ''

    if (byType) {
      // Export detailed results by room type
      const { data: results, error: resultsError } = await supabaseClient
        .from('forecast_results_by_type')
        .select(`
          *,
          room_types (code, label)
        `)
        .eq('scenario_id', scenarioId)
        .order('year, month, room_types.sort_order')

      if (resultsError) {
        return new Response(
          JSON.stringify({ error: 'Failed to fetch forecast results' }),
          { 
            status: 500, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        )
      }

      // Generate CSV header
      csvData = 'Année,Mois,Type de chambre,Code,Occupancy (%),Chambres vendues,ADR ($),RevPAR ($),Revenus ($)\n'

      // Generate CSV rows
      for (const result of results || []) {
        const monthNames = [
          'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
          'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
        ]
        
        csvData += `${result.year},${monthNames[result.month - 1]},${result.room_types?.label || 'N/A'},${result.room_types?.code || 'N/A'},${(result.occ_pct * 100).toFixed(2)},${result.rooms_sold},${result.adr.toFixed(2)},${result.revpar.toFixed(2)},${result.room_revenue.toFixed(2)}\n`
      }

      filename = `previsions_detaillees_${scenario.name.replace(/[^a-zA-Z0-9]/g, '_')}_${new Date().toISOString().split('T')[0]}.csv`
    } else {
      // Export aggregate results
      const { data: results, error: resultsError } = await supabaseClient
        .from('forecast_results')
        .select('*')
        .eq('scenario_id', scenarioId)
        .order('year, month')

      if (resultsError) {
        return new Response(
          JSON.stringify({ error: 'Failed to fetch forecast results' }),
          { 
            status: 500, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        )
      }

      // Generate CSV header
      csvData = 'Année,Mois,Occupancy (%),Chambres vendues,ADR ($),RevPAR ($),Revenus ($)\n'

      // Generate CSV rows
      for (const result of results || []) {
        const monthNames = [
          'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
          'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
        ]
        
        csvData += `${result.year},${monthNames[result.month - 1]},${(result.occ_pct * 100).toFixed(2)},${result.rooms_sold},${result.adr.toFixed(2)},${result.revpar.toFixed(2)},${result.room_revenue.toFixed(2)}\n`
      }

      filename = `previsions_agregees_${scenario.name.replace(/[^a-zA-Z0-9]/g, '_')}_${new Date().toISOString().split('T')[0]}.csv`
    }

    // Upload CSV to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabaseClient.storage
      .from('forecast-exports')
      .upload(filename, csvData, {
        contentType: 'text/csv',
        upsert: true
      })

    if (uploadError) {
      console.error('Upload error:', uploadError)
      return new Response(
        JSON.stringify({ error: 'Failed to upload CSV file' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Generate signed URL for download
    const { data: signedUrlData, error: signedUrlError } = await supabaseClient.storage
      .from('forecast-exports')
      .createSignedUrl(filename, 3600) // 1 hour expiry

    if (signedUrlError || !signedUrlData) {
      return new Response(
        JSON.stringify({ error: 'Failed to generate download URL' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        filename,
        downloadUrl: signedUrlData.signedUrl,
        message: 'CSV export generated successfully'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Error in export_forecast_csv function:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})