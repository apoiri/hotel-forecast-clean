import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Create Supabase client with service role key
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get request body
    const { hotelId, scenarioId, year } = await req.json()

    if (!hotelId || !scenarioId || !year) {
      return new Response(
        JSON.stringify({ error: 'Missing required parameters' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Fetch scenario and parameters
    const { data: scenario, error: scenarioError } = await supabaseClient
      .from('scenarios')
      .select(`
        *,
        forecast_params (*)
      `)
      .eq('id', scenarioId)
      .single()

    if (scenarioError || !scenario) {
      return new Response(
        JSON.stringify({ error: 'Scenario not found' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Fetch hotel data
    const { data: hotel, error: hotelError } = await supabaseClient
      .from('hotels')
      .select('*')
      .eq('id', hotelId)
      .single()

    if (hotelError || !hotel) {
      return new Response(
        JSON.stringify({ error: 'Hotel not found' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Fetch room types
    const { data: roomTypes, error: roomTypesError } = await supabaseClient
      .from('room_types')
      .select('*')
      .eq('hotel_id', hotelId)
      .eq('is_active', true)
      .order('sort_order')

    if (roomTypesError) {
      return new Response(
        JSON.stringify({ error: 'Failed to fetch room types' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Fetch baseline data
    const { data: occupancyBaseline, error: occError } = await supabaseClient
      .from('occupancy_baseline')
      .select('*')
      .eq('hotel_id', hotelId)
      .eq('year', year)

    const { data: adrBaseline, error: adrError } = await supabaseClient
      .from('adr_baseline')
      .select('*')
      .eq('hotel_id', hotelId)
      .eq('year', year)

    // Fetch seasonality
    const { data: seasonality, error: seasonError } = await supabaseClient
      .from('seasonality')
      .select('*')
      .eq('hotel_id', hotelId)

    // Fetch demand events
    const { data: demandEvents, error: eventsError } = await supabaseClient
      .from('demand_events')
      .select('*')
      .eq('hotel_id', hotelId)

    // Fetch room type monthly pricing
    const { data: roomTypePricing, error: pricingError } = await supabaseClient
      .from('room_type_monthly_pricing')
      .select('*')
      .eq('hotel_id', hotelId)
      .eq('year', year)

    if (occError || adrError || seasonError || eventsError || pricingError) {
      return new Response(
        JSON.stringify({ error: 'Failed to fetch baseline data' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Calculate forecast for each month
    const forecastResults = []
    const forecastResultsByType = []

    for (let month = 1; month <= 12; month++) {
      const monthData = {
        month,
        year,
        hotelId,
        scenarioId,
        // Get baseline data for this month
        baseOcc: occupancyBaseline?.find(b => b.month === month)?.base_occ_pct || 0.6,
        baseAdr: adrBaseline?.find(b => b.month === month)?.base_adr || 150,
        // Get seasonality for this month
        seasonalityOcc: seasonality?.find(s => s.month === month)?.occ_index || 1.0,
        seasonalityAdr: seasonality?.find(s => s.month === month)?.adr_index || 1.0,
        // Get demand events for this month
        events: demandEvents?.filter(e => {
          const startDate = new Date(e.start_date)
          const endDate = new Date(e.end_date)
          const monthStart = new Date(year, month - 1, 1)
          const monthEnd = new Date(year, month, 0)
          return startDate <= monthEnd && endDate >= monthStart
        }) || []
      }

      // Calculate for each room type
      let totalRevenue = 0
      let totalRoomsSold = 0
      let totalRoomsAvailable = 0

      for (const roomType of roomTypes) {
        const roomTypePricingData = roomTypePricing?.find(p => 
          p.room_type_id === roomType.id && p.month === month
        )

        // Calculate effective ADR for this room type
        let effectiveAdr = roomType.base_adr
        if (roomTypePricingData) {
          if (roomTypePricingData.override_adr) {
            effectiveAdr = roomTypePricingData.override_adr
          } else {
            effectiveAdr = roomType.base_adr * (1 + roomTypePricingData.market_adj_pct)
          }
        }

        // Apply seasonality
        effectiveAdr *= monthData.seasonalityAdr

        // Apply scenario adjustments
        const adjustments = scenario.adjustments || {}
        effectiveAdr *= (1 + (adjustments.adr_adj_pct || 0))

        // Calculate occupancy for this room type
        let occupancy = monthData.baseOcc * monthData.seasonalityOcc

        // Apply demand events
        for (const event of monthData.events) {
          const eventStart = new Date(event.start_date)
          const eventEnd = new Date(event.end_date)
          const monthStart = new Date(year, month - 1, 1)
          const monthEnd = new Date(year, month, 0)
          
          const overlapStart = eventStart > monthStart ? eventStart : monthStart
          const overlapEnd = eventEnd < monthEnd ? eventEnd : monthEnd
          
          if (overlapStart <= overlapEnd) {
            const overlapDays = Math.max(0, (overlapEnd.getTime() - overlapStart.getTime()) / (1000 * 3600 * 24) + 1)
            const monthDays = new Date(year, month, 0).getDate()
            const eventWeight = overlapDays / monthDays
            
            occupancy += (event.occ_uplift_pct || 0) * eventWeight
            effectiveAdr += (event.adr_uplift_pct || 0) * effectiveAdr * eventWeight
          }
        }

        // Apply scenario adjustments
        occupancy *= (1 + (adjustments.occ_adj_pct || 0))

        // Ensure occupancy is within bounds
        occupancy = Math.max(0, Math.min(1, occupancy))

        // Calculate rooms sold and revenue
        const daysInMonth = new Date(year, month, 0).getDate()
        const roomsSold = Math.round(roomType.rooms_count * occupancy * daysInMonth)
        const roomRevenue = roomsSold * effectiveAdr
        const revpar = roomRevenue / (roomType.rooms_count * daysInMonth)

        // Store room type specific results
        forecastResultsByType.push({
          room_type_id: roomType.id,
          year,
          month,
          occ_pct: occupancy,
          rooms_sold: roomsSold,
          adr: effectiveAdr,
          revpar,
          room_revenue: roomRevenue
        })

        // Add to totals
        totalRevenue += roomRevenue
        totalRoomsSold += roomsSold
        totalRoomsAvailable += roomType.rooms_count * daysInMonth
      }

      // Calculate aggregate metrics
      const totalOccupancy = totalRoomsAvailable > 0 ? totalRoomsSold / totalRoomsAvailable : 0
      const totalAdr = totalRoomsSold > 0 ? totalRevenue / totalRoomsSold : 0
      const totalRevpar = totalRoomsAvailable > 0 ? totalRevenue / totalRoomsAvailable : 0

      forecastResults.push({
        year,
        month,
        occ_pct: totalOccupancy,
        rooms_sold: totalRoomsSold,
        adr: totalAdr,
        revpar: totalRevpar,
        room_revenue: totalRevenue
      })
    }

    // Upsert forecast results by type
    if (forecastResultsByType.length > 0) {
      const { error: upsertByTypeError } = await supabaseClient
        .from('forecast_results_by_type')
        .upsert(
          forecastResultsByType.map(result => ({
            ...result,
            hotel_id: hotelId,
            scenario_id: scenarioId
          })),
          { onConflict: 'scenario_id,room_type_id,year,month' }
        )

      if (upsertByTypeError) {
        console.error('Error upserting forecast results by type:', upsertByTypeError)
      }
    }

    // Upsert aggregate forecast results
    if (forecastResults.length > 0) {
      const { error: upsertError } = await supabaseClient
        .from('forecast_results')
        .upsert(
          forecastResults.map(result => ({
            ...result,
            hotel_id: hotelId,
            scenario_id: scenarioId
          })),
          { onConflict: 'scenario_id,year,month' }
        )

      if (upsertError) {
        console.error('Error upserting forecast results:', upsertError)
        return new Response(
          JSON.stringify({ error: 'Failed to save forecast results' }),
          { 
            status: 500, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        )
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Forecast calculated successfully',
        resultsCount: forecastResults.length,
        resultsByTypeCount: forecastResultsByType.length
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Error in compute_forecast function:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})