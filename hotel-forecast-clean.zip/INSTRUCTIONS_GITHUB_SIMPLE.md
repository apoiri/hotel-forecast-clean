# Instructions GitHub - Version Simple

## 🚀 Étapes pour pousser sur GitHub

### 1. Créer le repository sur GitHub.com
1. Aller sur https://github.com
2. Cliquer sur le bouton **"New"** ou **"+"** puis **"New repository"**
3. **Nom du repository** : `hotel-forecast-clean` (ou autre nom de votre choix)
4. **Description** : "Application de prévisions hôtelières avec Next.js et Supabase - Version Clean"
5. **Visibilité** : Public ou Private (selon votre préférence)
6. **IMPORTANT** : Ne PAS cocher "Add README" (vous en avez déjà un)
7. Cliquer **"Create repository"**

### 2. Copier l'URL du repository
Après avoir créé le repository, GitHub vous donnera une URL comme :
`https://github.com/VOTRE_USERNAME/hotel-forecast-clean.git`

### 3. Exécuter ces commandes dans le terminal
```bash
cd /Users/alainpoirier/Desktop/Cursor/hotel-previsions-clean

# Remplacer VOTRE_USERNAME et NOM_REPO par vos vraies valeurs
git remote add origin https://github.com/VOTRE_USERNAME/NOM_REPO.git

# Pousser le code
git push -u origin main
```

### 4. Exemple concret
Si votre nom d'utilisateur GitHub est `alainpoirier` et que vous nommez le repository `hotel-forecast-clean` :

```bash
cd /Users/alainpoirier/Desktop/Cursor/hotel-previsions-clean
git remote add origin https://github.com/alainpoirier/hotel-forecast-clean.git
git push -u origin main
```

## 🎯 Prochaine étape
Une fois le code sur GitHub, vous pourrez déployer sur Vercel en important ce repository.

## 📝 Variables d'environnement pour Vercel
```
NEXT_PUBLIC_SUPABASE_URL=https://eihrmhpetbjpeosgtxck.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVpaHJtaHBldGJqcGVvc2d0eGNrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcwODIwNTYsImV4cCI6MjA3MjY1ODA1Nn0.mM1pNb_a8laObxEQAr2Cem0NTWNPj-Xt7m1Z-89OP_I
NODE_ENV=production
NEXT_TELEMETRY_DISABLED=1
```
