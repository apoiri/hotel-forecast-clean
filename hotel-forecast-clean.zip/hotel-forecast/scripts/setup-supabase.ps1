# Script de configuration Supabase pour Windows
# Configure Supabase localement pour le développement

Write-Host "🔧 Configuration de Supabase Local" -ForegroundColor Green
Write-Host ""

# Vérifier si Supabase CLI est installé
try {
    $supabaseVersion = supabase --version
    Write-Host "✅ Supabase CLI détecté: $supabaseVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Supabase CLI n'est pas installé" -ForegroundColor Red
    Write-Host "📦 Installation de Supabase CLI..." -ForegroundColor Yellow
    
    # Essayer d'installer via npm
    npm install -g @supabase/cli
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ Erreur lors de l'installation de Supabase CLI" -ForegroundColor Red
        Write-Host "💡 Installez manuellement depuis: https://supabase.com/docs/guides/cli" -ForegroundColor Yellow
        exit 1
    }
}

# Vérifier si Docker est en cours d'exécution
try {
    docker --version | Out-Null
    Write-Host "✅ Docker détecté" -ForegroundColor Green
} catch {
    Write-Host "❌ Docker n'est pas en cours d'exécution" -ForegroundColor Red
    Write-Host "💡 Démarrez Docker Desktop et réessayez" -ForegroundColor Yellow
    exit 1
}

# Démarrer Supabase
Write-Host "🚀 Démarrage de Supabase local..." -ForegroundColor Green
supabase start

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "✅ Supabase démarré avec succès!" -ForegroundColor Green
    Write-Host "📊 Studio: http://localhost:54323" -ForegroundColor Cyan
    Write-Host "🔗 API: http://localhost:54321" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "📝 Copiez les clés dans votre fichier .env.local:" -ForegroundColor Yellow
    
    # Afficher les clés
    $config = supabase status --output json | ConvertFrom-Json
    Write-Host "NEXT_PUBLIC_SUPABASE_URL=$($config.api)" -ForegroundColor White
    Write-Host "NEXT_PUBLIC_SUPABASE_ANON_KEY=$($config.anon_key)" -ForegroundColor White
} else {
    Write-Host "❌ Erreur lors du démarrage de Supabase" -ForegroundColor Red
    exit 1
}

