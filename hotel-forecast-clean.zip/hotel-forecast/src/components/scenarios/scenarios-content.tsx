'use client'

import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Plus, Play, Download, Eye, Edit, Trash2 } from 'lucide-react'
import { toast } from 'sonner'

export function ScenariosContent() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingScenario, setEditingScenario] = useState<any>(null)
  const [formData, setFormData] = useState({
    name: '',
    params_id: '',
    visibility: 'private' as 'private' | 'org',
    adjustments: {
      global: {
        occ_shift_pct: 0,
        adr_shift_pct: 0,
        blocked_rooms: 0
      },
      segments: {}
    }
  })
  
  const supabase = createClient()
  const queryClient = useQueryClient()

  // Fetch scenarios
  const { data: scenarios } = useQuery({
    queryKey: ['scenarios'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('scenarios')
        .select(`
          *,
          forecast_params!inner(name)
        `)
        .order('created_at', { ascending: false })
      
      if (error) throw error
      return data
    }
  })

  // Fetch forecast params
  const { data: forecastParams } = useQuery({
    queryKey: ['forecast-params'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('forecast_params')
        .select('*')
        .order('name')
      
      if (error) throw error
      return data
    }
  })

  // Create/Update scenario
  const saveScenarioMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      if (editingScenario) {
        const { error } = await supabase
          .from('scenarios')
          .update(data)
          .eq('id', editingScenario.id)
        
        if (error) throw error
      } else {
        const { error } = await supabase
          .from('scenarios')
          .insert(data)
        
        if (error) throw error
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scenarios'] })
      toast.success(editingScenario ? 'Scénario mis à jour' : 'Scénario créé')
      setIsDialogOpen(false)
      setEditingScenario(null)
      resetForm()
    },
    onError: (error) => {
      toast.error('Erreur: ' + error.message)
    }
  })

  // Delete scenario
  const deleteScenarioMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('scenarios')
        .delete()
        .eq('id', id)
      
      if (error) throw error
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scenarios'] })
      toast.success('Scénario supprimé')
    },
    onError: (error) => {
      toast.error('Erreur: ' + error.message)
    }
  })

  // Compute forecast
  const computeForecastMutation = useMutation({
    mutationFn: async (scenarioId: string) => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error('Non authentifié')

      const { data: profile } = await supabase
        .from('profiles')
        .select('hotel_id')
        .eq('user_id', user.id)
        .single()

      if (!profile) throw new Error('Profil non trouvé')

      const response = await fetch('/api/compute-forecast', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`
        },
        body: JSON.stringify({
          hotelId: profile.hotel_id,
          scenarioId,
          year: 2025
        })
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || 'Erreur lors du calcul')
      }

      return response.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['forecast-results'] })
      toast.success('Prévision calculée avec succès')
    },
    onError: (error) => {
      toast.error('Erreur lors du calcul: ' + error.message)
    }
  })

  const resetForm = () => {
    setFormData({
      name: '',
      params_id: '',
      visibility: 'private',
      adjustments: {
        global: {
          occ_shift_pct: 0,
          adr_shift_pct: 0,
          blocked_rooms: 0
        },
        segments: {}
      }
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    saveScenarioMutation.mutate(formData)
  }

  const handleEdit = (scenario: any) => {
    setEditingScenario(scenario)
    setFormData({
      name: scenario.name,
      params_id: scenario.params_id,
      visibility: scenario.visibility,
      adjustments: scenario.adjustments
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce scénario ?')) {
      deleteScenarioMutation.mutate(id)
    }
  }

  const handleNew = () => {
    setEditingScenario(null)
    resetForm()
    setIsDialogOpen(true)
  }

  const handleCompute = (scenarioId: string) => {
    computeForecastMutation.mutate(scenarioId)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR')
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Scénarios</h1>
          <p className="text-gray-600">Gérez vos scénarios de prévision</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleNew}>
              <Plus className="h-4 w-4 mr-2" />
              Nouveau scénario
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingScenario ? 'Modifier le scénario' : 'Nouveau scénario'}
              </DialogTitle>
              <DialogDescription>
                Créez un nouveau scénario de prévision avec des ajustements personnalisés
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nom du scénario</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="ex: Scénario optimiste"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="params_id">Paramètres de base</Label>
                  <Select value={formData.params_id} onValueChange={(value) => setFormData(prev => ({ ...prev, params_id: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner les paramètres" />
                    </SelectTrigger>
                    <SelectContent>
                      {forecastParams?.map((param) => (
                        <SelectItem key={param.id} value={param.id}>
                          {param.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="visibility">Visibilité</Label>
                <Select value={formData.visibility} onValueChange={(value: 'private' | 'org') => setFormData(prev => ({ ...prev, visibility: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="private">Privé</SelectItem>
                    <SelectItem value="org">Organisation</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Ajustements globaux</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="occ_shift_pct">Variation occupation (%)</Label>
                    <Input
                      id="occ_shift_pct"
                      type="number"
                      step="0.01"
                      value={formData.adjustments.global.occ_shift_pct}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        adjustments: {
                          ...prev.adjustments,
                          global: {
                            ...prev.adjustments.global,
                            occ_shift_pct: parseFloat(e.target.value) || 0
                          }
                        }
                      }))}
                      placeholder="ex: 5 pour +5%"
                    />
                  </div>
                  <div>
                    <Label htmlFor="adr_shift_pct">Variation ADR (%)</Label>
                    <Input
                      id="adr_shift_pct"
                      type="number"
                      step="0.01"
                      value={formData.adjustments.global.adr_shift_pct}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        adjustments: {
                          ...prev.adjustments,
                          global: {
                            ...prev.adjustments.global,
                            adr_shift_pct: parseFloat(e.target.value) || 0
                          }
                        }
                      }))}
                      placeholder="ex: 3 pour +3%"
                    />
                  </div>
                  <div>
                    <Label htmlFor="blocked_rooms">Chambres bloquées</Label>
                    <Input
                      id="blocked_rooms"
                      type="number"
                      min="0"
                      value={formData.adjustments.global.blocked_rooms}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        adjustments: {
                          ...prev.adjustments,
                          global: {
                            ...prev.adjustments.global,
                            blocked_rooms: parseInt(e.target.value) || 0
                          }
                        }
                      }))}
                      placeholder="ex: 5"
                    />
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit" disabled={saveScenarioMutation.isPending}>
                  {editingScenario ? 'Mettre à jour' : 'Créer'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Scénarios disponibles</CardTitle>
          <CardDescription>Liste de tous vos scénarios de prévision</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nom</TableHead>
                <TableHead>Paramètres</TableHead>
                <TableHead>Visibilité</TableHead>
                <TableHead>Créé le</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {scenarios?.map((scenario) => (
                <TableRow key={scenario.id}>
                  <TableCell className="font-medium">{scenario.name}</TableCell>
                  <TableCell>{scenario.forecast_params.name}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      scenario.visibility === 'private' 
                        ? 'bg-gray-100 text-gray-800' 
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {scenario.visibility === 'private' ? 'Privé' : 'Organisation'}
                    </span>
                  </TableCell>
                  <TableCell>{formatDate(scenario.created_at)}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleCompute(scenario.id)}
                        disabled={computeForecastMutation.isPending}
                      >
                        <Play className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(scenario)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(scenario.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
