'use client'

import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Plus, Edit, Trash2, Calendar } from 'lucide-react'
import { toast } from 'sonner'

export function EventsSettings() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingEvent, setEditingEvent] = useState<any>(null)
  const [formData, setFormData] = useState({
    name: '',
    start_date: '',
    end_date: '',
    occ_uplift_pct: 0,
    adr_uplift_pct: 0
  })
  
  const supabase = createClient()
  const queryClient = useQueryClient()

  // Fetch events
  const { data: events } = useQuery({
    queryKey: ['demand-events'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('demand_events')
        .select('*')
        .order('start_date')
      
      if (error) throw error
      return data
    }
  })

  // Create/Update event
  const saveEventMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      if (editingEvent) {
        const { error } = await supabase
          .from('demand_events')
          .update(data)
          .eq('id', editingEvent.id)
        
        if (error) throw error
      } else {
        const { error } = await supabase
          .from('demand_events')
          .insert(data)
        
        if (error) throw error
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['demand-events'] })
      toast.success(editingEvent ? 'Événement mis à jour' : 'Événement créé')
      setIsDialogOpen(false)
      setEditingEvent(null)
      setFormData({ name: '', start_date: '', end_date: '', occ_uplift_pct: 0, adr_uplift_pct: 0 })
    },
    onError: (error) => {
      toast.error('Erreur: ' + error.message)
    }
  })

  // Delete event
  const deleteEventMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('demand_events')
        .delete()
        .eq('id', id)
      
      if (error) throw error
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['demand-events'] })
      toast.success('Événement supprimé')
    },
    onError: (error) => {
      toast.error('Erreur: ' + error.message)
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    saveEventMutation.mutate(formData)
  }

  const handleEdit = (event: any) => {
    setEditingEvent(event)
    setFormData({
      name: event.name,
      start_date: event.start_date,
      end_date: event.end_date,
      occ_uplift_pct: event.occ_uplift_pct,
      adr_uplift_pct: event.adr_uplift_pct
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet événement ?')) {
      deleteEventMutation.mutate(id)
    }
  }

  const handleNew = () => {
    setEditingEvent(null)
    setFormData({ name: '', start_date: '', end_date: '', occ_uplift_pct: 0, adr_uplift_pct: 0 })
    setIsDialogOpen(true)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR')
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Événements de demande</h2>
          <p className="text-gray-600">Gérez les événements qui affectent la demande et les prix</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleNew}>
              <Plus className="h-4 w-4 mr-2" />
              Nouvel événement
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingEvent ? 'Modifier l\'événement' : 'Nouvel événement'}
              </DialogTitle>
              <DialogDescription>
                Définissez les caractéristiques de l'événement et son impact
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Nom de l'événement</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="ex: Congrès médical"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="start_date">Date de début</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => setFormData(prev => ({ ...prev, start_date: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="end_date">Date de fin</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData(prev => ({ ...prev, end_date: e.target.value }))}
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="occ_uplift_pct">Impact occupation (%)</Label>
                  <Input
                    id="occ_uplift_pct"
                    type="number"
                    min="-100"
                    max="100"
                    step="0.01"
                    value={formData.occ_uplift_pct}
                    onChange={(e) => setFormData(prev => ({ ...prev, occ_uplift_pct: parseFloat(e.target.value) || 0 }))}
                    placeholder="ex: 15 pour +15%"
                  />
                </div>
                <div>
                  <Label htmlFor="adr_uplift_pct">Impact ADR (%)</Label>
                  <Input
                    id="adr_uplift_pct"
                    type="number"
                    min="-100"
                    max="100"
                    step="0.01"
                    value={formData.adr_uplift_pct}
                    onChange={(e) => setFormData(prev => ({ ...prev, adr_uplift_pct: parseFloat(e.target.value) || 0 }))}
                    placeholder="ex: 10 pour +10%"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit" disabled={saveEventMutation.isPending}>
                  {editingEvent ? 'Mettre à jour' : 'Créer'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Événements configurés</CardTitle>
          <CardDescription>Liste des événements qui affectent la demande</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nom</TableHead>
                <TableHead>Période</TableHead>
                <TableHead>Impact occupation</TableHead>
                <TableHead>Impact ADR</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {events?.map((event) => (
                <TableRow key={event.id}>
                  <TableCell className="font-medium">{event.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-gray-400" />
                      <span>{formatDate(event.start_date)} - {formatDate(event.end_date)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className={`font-medium ${event.occ_uplift_pct >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {event.occ_uplift_pct >= 0 ? '+' : ''}{event.occ_uplift_pct}%
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className={`font-medium ${event.adr_uplift_pct >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {event.adr_uplift_pct >= 0 ? '+' : ''}{event.adr_uplift_pct}%
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(event)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(event.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
