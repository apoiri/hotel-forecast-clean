// supabase/functions/export_forecast_csv/index.ts
import 'jsr:@supabase/functions-js/edge-runtime.d.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { z } from 'https://esm.sh/zod@3'

const InputSchema = z.object({
  scenarioId: z.string().uuid(),
  byType: z.boolean().optional()
})

Deno.serve(async (req) => {
  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseAnon = Deno.env.get('SUPABASE_ANON_KEY')!
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

    const authClient = createClient(supabaseUrl, supabaseAnon, {
      global: { headers: { Authorization: req.headers.get('Authorization')! } }
    })
    const serviceClient = createClient(supabaseUrl, serviceRoleKey)

    const { data: { user } } = await authClient.auth.getUser()
    if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 })

    const body = await req.json()
    const { scenarioId, byType } = InputSchema.parse(body)

    // Load scenario + membership check
    const { data: sc } = await authClient.from('scenarios').select('id, hotel_id').eq('id', scenarioId).single()
    if (!sc) return new Response(JSON.stringify({ error: 'Scenario not found' }), { status: 404 })
    const { data: me } = await authClient.from('profiles').select('hotel_id').eq('user_id', user.id).single()
    if (!me || me.hotel_id !== sc.hotel_id) return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403 })

    // Fetch data
    const table = byType ? 'forecast_results_by_type' : 'forecast_results'
    const cols = byType
      ? 'year,month,room_type_id,occ_pct,rooms_sold,adr,revpar,room_revenue'
      : 'year,month,occ_pct,rooms_sold,adr,revpar,room_revenue'
    const { data: rows } = await serviceClient.from(table).select(cols).eq('scenario_id', scenarioId).order('year').order('month')

    const header = byType
      ? ['year','month','room_type_id','occ_pct','rooms_sold','adr','revpar','room_revenue']
      : ['year','month','occ_pct','rooms_sold','adr','revpar','room_revenue']

    const csv = [header.join(','), ...(rows ?? []).map(r =>
      header.map(h => r[h] ?? '').join(',')
    )].join('\n')

    const path = `exports/${scenarioId}/${byType ? 'by_type' : 'aggregate'}.csv`
    const { error: upErr } = await serviceClient.storage.from('exports').upload(path, new Blob([csv], { type: 'text/csv' }), { upsert: true })
    if (upErr) return new Response(JSON.stringify({ error: upErr.message }), { status: 500 })

    const { data: signed } = await serviceClient.storage.from('exports').createSignedUrl(path, 60 * 5)
    return new Response(JSON.stringify({ url: signed?.signedUrl }), { status: 200 })
  } catch (e) {
    console.error(e)
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 })
  }
})
