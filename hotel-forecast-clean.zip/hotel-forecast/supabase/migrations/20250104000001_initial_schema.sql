-- ─────────────────────────────────────────────────────────────────────────────
-- INITIAL SCHEMA - HOTEL FORECAST APPLICATION
-- ─────────────────────────────────────────────────────────────────────────────

-- 01) Organisations & hôtels
create table if not exists public.organizations(
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz default now()
);

create table if not exists public.hotels(
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  city text default 'Ottawa',
  timezone text default 'America/Toronto',
  currency text default 'CAD',
  rooms_total int not null default 100,
  created_at timestamptz default now()
);

-- 02) Profils utilisateurs
create table if not exists public.profiles(
  user_id uuid primary key references auth.users(id) on delete cascade,
  org_id uuid not null references public.organizations(id) on delete restrict,
  hotel_id uuid not null references public.hotels(id) on delete restrict,
  role text not null check (role in ('admin','manager','analyst','student')),
  created_at timestamptz default now()
);

-- 03) Segments (origines clientèle)
create table if not exists public.segments(
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  label text not null
);

-- 04) Baselines & saisonnalité
create table if not exists public.occupancy_baseline(
  hotel_id uuid references public.hotels(id) on delete cascade,
  year int not null,
  month int not null check (month between 1 and 12),
  base_occ_pct numeric not null check (base_occ_pct between 0 and 1),
  primary key (hotel_id, year, month)
);

create table if not exists public.adr_baseline(
  hotel_id uuid references public.hotels(id) on delete cascade,
  year int not null,
  month int not null check (month between 1 and 12),
  base_adr numeric not null check (base_adr > 0),
  primary key (hotel_id, year, month)
);

create table if not exists public.seasonality(
  hotel_id uuid references public.hotels(id) on delete cascade,
  month int not null check (month between 1 and 12),
  occ_index numeric not null default 1.0,
  adr_index numeric not null default 1.0,
  primary key (hotel_id, month)
);

-- 05) Événements de demande (uplifts)
create table if not exists public.demand_events(
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid references public.hotels(id) on delete cascade,
  name text not null,
  start_date date not null,
  end_date date not null check (end_date >= start_date),
  occ_uplift_pct numeric not null default 0, -- ex: 0.10 = +10% d'occupation
  adr_uplift_pct numeric not null default 0,
  locked boolean default false
);

-- 06) Paramètres de forecast & mix
create table if not exists public.forecast_params(
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid references public.hotels(id) on delete cascade,
  name text not null,
  description text,
  segment_share jsonb not null, -- { "CAN_FR":0.2, "CAN_EN":0.3, ... } somme=1.0
  created_by uuid references auth.users(id),
  created_at timestamptz default now()
);

-- 07) Scénarios
create table if not exists public.scenarios(
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid references public.hotels(id) on delete cascade,
  params_id uuid references public.forecast_params(id) on delete restrict,
  name text not null,
  adjustments jsonb not null, 
  /* exemple:
    {
      "global": {"occ_shift_pct":0.05, "adr_shift_pct":0.03, "blocked_rooms":5},
      "segments": {"USA":{"share_delta":0.05},"EUR":{"share_delta":-0.03}}
    }
  */
  visibility text not null default 'private' check (visibility in ('private','org')),
  created_by uuid references auth.users(id),
  created_at timestamptz default now()
);

-- 08) Résultats mensuels
create table if not exists public.forecast_results(
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid references public.hotels(id) on delete cascade,
  scenario_id uuid references public.scenarios(id) on delete cascade,
  year int not null,
  month int not null check (month between 1 and 12),
  occ_pct numeric not null check (occ_pct between 0 and 1),
  rooms_sold int not null,
  adr numeric not null,
  revpar numeric not null,
  room_revenue numeric not null,
  created_at timestamptz default now(),
  unique (scenario_id, year, month)
);

-- 09) Audit
create table if not exists public.audit_log(
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  action text not null,
  entity text not null,
  entity_id uuid,
  payload jsonb,
  created_at timestamptz default now()
);

-- ─────────────────────────────────────────────────────────────────────────────
-- ROOM TYPES & MONTHLY PRICING
-- ─────────────────────────────────────────────────────────────────────────────

create table if not exists public.room_types (
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid not null references public.hotels(id) on delete cascade,
  code text not null,
  label text not null,
  base_adr numeric not null check (base_adr > 0),
  rooms_count int not null check (rooms_count >= 0),
  is_active boolean not null default true,
  sort_order int not null default 0,
  unique (hotel_id, code)
);

-- Ajustements mensuels de prix par type (conditions de marché)
create table if not exists public.room_type_monthly_pricing (
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid not null references public.hotels(id) on delete cascade,
  room_type_id uuid not null references public.room_types(id) on delete cascade,
  year int not null,
  month int not null check (month between 1 and 12),
  -- multiplicateur du marché (ex: 0.05 = +5%), appliqué sur le ADR combiné base * saison * événements
  market_adj_pct numeric not null default 0,
  -- override optionnel du ADR final si non nul (prend le dessus)
  override_adr numeric,
  created_by uuid references auth.users(id),
  created_at timestamptz default now(),
  unique (room_type_id, year, month)
);

-- Résultats par type (en plus du cumul mensuel déjà en place dans forecast_results).
create table if not exists public.forecast_results_by_type (
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid not null references public.hotels(id) on delete cascade,
  scenario_id uuid not null references public.scenarios(id) on delete cascade,
  room_type_id uuid not null references public.room_types(id) on delete cascade,
  year int not null,
  month int not null check (month between 1 and 12),
  occ_pct numeric not null check (occ_pct between 0 and 1),       -- occupation du type
  rooms_sold int not null,                                        -- nuitées vendues pour ce type
  adr numeric not null,                                           -- ADR final de ce type
  revpar numeric not null,
  room_revenue numeric not null,
  created_at timestamptz default now(),
  unique (scenario_id, room_type_id, year, month)
);

-- ─────────────────────────────────────────────────────────────────────────────
-- INDEX
-- ─────────────────────────────────────────────────────────────────────────────
create index if not exists idx_forecast_results_hotel_scenario on public.forecast_results(hotel_id, scenario_id, year, month);
create index if not exists idx_demand_events_hotel on public.demand_events(hotel_id, start_date, end_date);
create index if not exists idx_profiles_hotel_role on public.profiles(hotel_id, role);
create index if not exists idx_room_types_hotel on public.room_types(hotel_id, is_active);
create index if not exists idx_room_type_monthly_pricing_hotel on public.room_type_monthly_pricing(hotel_id, year, month);
create index if not exists idx_forecast_results_by_type on public.forecast_results_by_type(hotel_id, scenario_id, room_type_id, year, month);

-- ─────────────────────────────────────────────────────────────────────────────
-- RLS DENY-BY-DEFAULT
-- ─────────────────────────────────────────────────────────────────────────────
alter table public.organizations enable row level security;
alter table public.hotels enable row level security;
alter table public.profiles enable row level security;
alter table public.segments enable row level security;
alter table public.occupancy_baseline enable row level security;
alter table public.adr_baseline enable row level security;
alter table public.seasonality enable row level security;
alter table public.demand_events enable row level security;
alter table public.forecast_params enable row level security;
alter table public.scenarios enable row level security;
alter table public.forecast_results enable row level security;
alter table public.audit_log enable row level security;
alter table public.room_types enable row level security;
alter table public.room_type_monthly_pricing enable row level security;
alter table public.forecast_results_by_type enable row level security;

-- Helper: vue pour connaître le profil courant
create or replace view public.me as
  select p.*, u.email
  from public.profiles p
  join auth.users u on u.id = p.user_id
  where p.user_id = auth.uid();

-- Politiques type : lecture restreinte à l'hôtel de l'utilisateur
create policy "read_hotel_scoped" on public.hotels
for select using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = hotels.id));

-- Exemple: profiles (lecture/écriture par admin/manager de son hôtel)
create policy "read_profiles_same_hotel" on public.profiles
for select using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = profiles.hotel_id));

create policy "write_profiles_admin" on public.profiles
for insert with check (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = profiles.hotel_id and pr.role in ('admin','manager')))
for update using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = profiles.hotel_id and pr.role in ('admin','manager')));

-- Baselines : écriture admin/manager, lecture tous membres
create policy "read_baseline" on public.occupancy_baseline
for select using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = occupancy_baseline.hotel_id));
create policy "write_baseline_admin_mgr" on public.occupancy_baseline
for insert with check (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = occupancy_baseline.hotel_id and pr.role in ('admin','manager')))
for update using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = occupancy_baseline.hotel_id and pr.role in ('admin','manager')));

create policy "read_adr_baseline" on public.adr_baseline
for select using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = adr_baseline.hotel_id));
create policy "write_adr_baseline_admin_mgr" on public.adr_baseline
for insert with check (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = adr_baseline.hotel_id and pr.role in ('admin','manager')))
for update using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = adr_baseline.hotel_id and pr.role in ('admin','manager')));

-- Saisonnalité
create policy "read_seasonality" on public.seasonality
for select using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = seasonality.hotel_id));
create policy "write_seasonality_admin_mgr" on public.seasonality
for insert with check (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = seasonality.hotel_id and pr.role in ('admin','manager')))
for update using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = seasonality.hotel_id and pr.role in ('admin','manager')));

-- Segments (lecture pour tous)
create policy "read_segments" on public.segments for select using (true);

-- Événements
create policy "read_events" on public.demand_events
for select using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = demand_events.hotel_id));
create policy "write_events_admin_mgr" on public.demand_events
for insert with check (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = demand_events.hotel_id and pr.role in ('admin','manager')))
for update using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = demand_events.hotel_id and pr.role in ('admin','manager')))
for delete using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = demand_events.hotel_id and pr.role in ('admin','manager')));

-- Paramètres de forecast
create policy "read_forecast_params" on public.forecast_params
for select using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = forecast_params.hotel_id));
create policy "write_forecast_params_admin_mgr" on public.forecast_params
for insert with check (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = forecast_params.hotel_id and pr.role in ('admin','manager')))
for update using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = forecast_params.hotel_id and pr.role in ('admin','manager')))
for delete using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = forecast_params.hotel_id and pr.role in ('admin','manager')));

-- Scénarios : propriétaire + visibilité org
create policy "read_scenarios" on public.scenarios
for select using (
  exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = scenarios.hotel_id)
  and (scenarios.visibility='org' or scenarios.created_by = auth.uid())
);
create policy "write_scenarios_owner" on public.scenarios
for insert with check (created_by = auth.uid()
  and exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = scenarios.hotel_id))
for update using (created_by = auth.uid())
for delete using (created_by = auth.uid());

-- Résultats de forecast
create policy "read_forecast_results" on public.forecast_results
for select using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.hotel_id = forecast_results.hotel_id));

-- Room types
create policy "read_room_types_same_hotel" on public.room_types
for select using (exists (
  select 1 from public.profiles pr
  where pr.user_id = auth.uid() and pr.hotel_id = room_types.hotel_id
));

create policy "write_room_types_admin_mgr" on public.room_types
for insert with check (exists (
  select 1 from public.profiles pr
  where pr.user_id = auth.uid() and pr.hotel_id = room_types.hotel_id and pr.role in ('admin','manager')
))
for update using (exists (
  select 1 from public.profiles pr
  where pr.user_id = auth.uid() and pr.hotel_id = room_types.hotel_id and pr.role in ('admin','manager')
))
for delete using (exists (
  select 1 from public.profiles pr
  where pr.user_id = auth.uid() and pr.hotel_id = room_types.hotel_id and pr.role in ('admin','manager')
));

-- Room type monthly pricing
create policy "read_room_type_monthly_same_hotel" on public.room_type_monthly_pricing
for select using (exists (
  select 1 from public.profiles pr
  where pr.user_id = auth.uid() and pr.hotel_id = room_type_monthly_pricing.hotel_id
));

create policy "write_room_type_monthly_admin_mgr" on public.room_type_monthly_pricing
for insert with check (exists (
  select 1 from public.profiles pr
  where pr.user_id = auth.uid() and pr.hotel_id = room_type_monthly_pricing.hotel_id and pr.role in ('admin','manager')
))
for update using (exists (
  select 1 from public.profiles pr
  where pr.user_id = auth.uid() and pr.hotel_id = room_type_monthly_pricing.hotel_id and pr.role in ('admin','manager')
))
for delete using (exists (
  select 1 from public.profiles pr
  where pr.user_id = auth.uid() and pr.hotel_id = room_type_monthly_pricing.hotel_id and pr.role in ('admin','manager')
));

-- Forecast results by type
create policy "read_results_by_type_same_hotel" on public.forecast_results_by_type
for select using (exists (
  select 1 from public.profiles pr
  where pr.user_id = auth.uid() and pr.hotel_id = forecast_results_by_type.hotel_id
));

-- Audit log (lecture pour admin/manager)
create policy "read_audit_log_admin_mgr" on public.audit_log
for select using (exists (select 1 from public.profiles pr where pr.user_id = auth.uid() and pr.role in ('admin','manager')));

-- ─────────────────────────────────────────────────────────────────────────────
-- VUES PRATIQUES
-- ─────────────────────────────────────────────────────────────────────────────
-- Vue de capacité totale par hôtel (somme des types actifs)
create or replace view public.hotel_capacity as
select h.id as hotel_id,
       coalesce(sum(rt.rooms_count),0) as rooms_total_active
from public.hotels h
left join public.room_types rt on rt.hotel_id = h.id and rt.is_active
group by h.id;

-- Vue ADR mensuel final par type (si override_adr non null -> prioritaire)
create or replace view public.room_type_effective_adr_monthly as
select
  rtmp.hotel_id,
  rtmp.room_type_id,
  rtmp.year,
  rtmp.month,
  case
    when rtmp.override_adr is not null then rtmp.override_adr
    else null -- calculé côté Edge avec saisonnalité/événements/scénario
  end as effective_adr_override_only
from public.room_type_monthly_pricing rtmp;
