# 🏨 Application de Prévision Hôtelière

Une application moderne de prévision de ventes pour hôtels, construite avec Next.js 14, Supabase et TypeScript.

## 🚀 Démarrage Rapide

### 1. Installation des dépendances
```bash
npm install
```

### 2. Configuration Supabase

#### Option A : Supabase Local (Recommandé pour le développement)
```bash
# Installer Supabase CLI
npm install -g @supabase/cli

# Démarrer Supabase localement
supabase start

# Appliquer les migrations
supabase db reset
```

#### Option B : Supabase Cloud
1. Créez un projet sur [supabase.com](https://supabase.com)
2. Copiez `env.example` vers `.env.local`
3. Remplissez vos clés Supabase :
```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

### 3. Lancer l'application
```bash
npm run dev
```

L'application sera disponible sur [http://localhost:3000](http://localhost:3000)

## 📊 Fonctionnalités

- **Dashboard** : Vue d'ensemble des prévisions mensuelles
- **Paramètres** : Configuration des baselines, saisonnalité, types de chambres
- **Événements** : Gestion des événements spéciaux
- **Scénarios** : Simulation et comparaison de scénarios
- **Export** : Export des données en CSV/Excel

## 🏗️ Architecture

- **Frontend** : Next.js 14 (App Router), TypeScript, Tailwind CSS
- **Backend** : Supabase (PostgreSQL, Auth, Edge Functions)
- **UI** : shadcn/ui, Recharts
- **State Management** : TanStack Query
- **Validation** : Zod, react-hook-form

## 📁 Structure du Projet

```
hotel-forecast/
├── src/
│   ├── app/                 # Pages Next.js
│   ├── components/          # Composants React
│   ├── lib/                 # Utilitaires et configuration
│   └── test/                # Tests
├── supabase/
│   ├── migrations/          # Migrations SQL
│   ├── functions/           # Edge Functions
│   └── seed.sql            # Données de test
└── public/                  # Assets statiques
```

## 🔧 Scripts Disponibles

```bash
npm run dev          # Développement
npm run build        # Build de production
npm run start        # Serveur de production
npm run lint         # Linting
npm run test         # Tests
```

## 🚀 Déploiement

L'application est prête pour le déploiement sur :
- **Vercel** (recommandé)
- **Netlify**
- **Railway**
- **DigitalOcean**

Voir le dossier `deploy/` pour les configurations spécifiques.

## 📝 Notes de Développement

- L'application utilise l'authentification Supabase
- Les Edge Functions gèrent les calculs complexes
- RLS (Row Level Security) est activé pour la sécurité
- Support multi-tenant (organisations/hôtels)

## 🤝 Contribution

1. Fork le projet
2. Créez une branche feature
3. Committez vos changements
4. Poussez vers la branche
5. Ouvrez une Pull Request

## 📄 Licence

MIT License - voir le fichier LICENSE pour plus de détails.