# Configuration de déploiement - Variables d'environnement

## Variables requises pour la production

### Supabase Configuration
```env
NEXT_PUBLIC_SUPABASE_URL=https://eihrmhpetbjpeosgtxck.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVpaHJtaHBldGJqcGVvc2d0eGNrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcwODIwNTYsImV4cCI6MjA3MjY1ODA1Nn0.mM1pNb_a8laObxEQAr2Cem0NTWNPj-Xt7m1Z-89OP_I
```

### Service Role Key (à obtenir depuis Supabase Dashboard > Settings > API)
```env
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key-here
```

### Application Configuration
```env
NODE_ENV=production
NEXT_TELEMETRY_DISABLED=1
PORT=3000
HOSTNAME=0.0.0.0
```

### URL de l'application (à configurer selon votre domaine)
```env
NEXT_PUBLIC_APP_URL=https://your-domain.com
```

## Configuration par plateforme

### Google Cloud Run
- Configurer via Cloud Console > Cloud Run > hotel-forecast > Variables d'environnement
- Ou via gcloud CLI :
```bash
gcloud run services update hotel-forecast \
  --set-env-vars="NEXT_PUBLIC_SUPABASE_URL=https://eihrmhpetbjpeosgtxck.supabase.co" \
  --set-env-vars="NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVpaHJtaHBldGJqcGVvc2d0eGNrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcwODIwNTYsImV4cCI6MjA3MjY1ODA1Nn0.mM1pNb_a8laObxEQAr2Cem0NTWNPj-Xt7m1Z-89OP_I"
```

### Vercel
- Configurer via Vercel Dashboard > Project Settings > Environment Variables
- Ajouter toutes les variables ci-dessus

### Netlify
- Configurer via Netlify Dashboard > Site Settings > Environment Variables
- Ajouter toutes les variables ci-dessus

### Azure App Service
- Configurer via Azure Portal > App Service > Configuration > Application Settings
- Ajouter toutes les variables ci-dessus
