#!/bin/bash

# Script pour pousser le code sur GitHub
# Hotel Forecast Application - Clean Version

echo "🚀 Push vers GitHub - Hotel Forecast Clean Version"
echo "=================================================="

# Vérifier que nous sommes dans le bon répertoire
if [ ! -f "hotel-forecast/package.json" ]; then
    echo "❌ Erreur: Ce script doit être exécuté depuis le dossier hotel-previsions-clean"
    exit 1
fi

# Demander le nom d'utilisateur GitHub
echo ""
echo "📝 Entrez votre nom d'utilisateur GitHub :"
read -p "Username: " GITHUB_USERNAME

if [ -z "$GITHUB_USERNAME" ]; then
    echo "❌ Nom d'utilisateur requis"
    exit 1
fi

# Demander le nom du repository
echo ""
echo "📝 Entrez le nom du repository (ou appuyez sur Entrée pour 'hotel-forecast-clean') :"
read -p "Repository name: " REPO_NAME

if [ -z "$REPO_NAME" ]; then
    REPO_NAME="hotel-forecast-clean"
fi

echo ""
echo "🔗 Configuration du remote GitHub..."
echo "Repository: https://github.com/$GITHUB_USERNAME/$REPO_NAME"

# Ajouter le remote
git remote add origin https://github.com/$GITHUB_USERNAME/$REPO_NAME.git

if [ $? -eq 0 ]; then
    echo "✅ Remote ajouté avec succès"
else
    echo "⚠️  Remote existe peut-être déjà, continuons..."
fi

# Pousser le code
echo ""
echo "📤 Poussage du code vers GitHub..."
git push -u origin main

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 Succès ! Votre code est maintenant sur GitHub :"
    echo "   https://github.com/$GITHUB_USERNAME/$REPO_NAME"
    echo ""
    echo "🚀 Prochaine étape : Déployer sur Vercel"
    echo "   1. Aller sur https://vercel.com"
    echo "   2. Importer le repository $REPO_NAME"
    echo "   3. Configurer les variables d'environnement :"
    echo "      - NEXT_PUBLIC_SUPABASE_URL=https://eihrmhpetbjpeosgtxck.supabase.co"
    echo "      - NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
    echo "      - NODE_ENV=production"
    echo "      - NEXT_TELEMETRY_DISABLED=1"
    echo "   4. Si nécessaire : Root Directory = hotel-forecast"
    echo "   5. Déployer !"
else
    echo ""
    echo "❌ Erreur lors du push. Vérifiez :"
    echo "   - Que le repository existe sur GitHub"
    echo "   - Que vous avez les permissions d'écriture"
    echo "   - Votre nom d'utilisateur et mot de passe/token"
fi
