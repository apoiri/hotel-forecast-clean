# Guide de déploiement Vercel - Hôtel Forecast

## 🚀 Étapes rapides sur votre nouvel ordinateur

### 1. Préparer le projet
```bash
# Copier le dossier hotel-previsions sur le nouvel ordinateur
# Puis dans le terminal :
cd hotel-previsions
```

### 2. Initialiser Git (sur le nouvel ordinateur)
```bash
# Supprimer tout repository Git existant
rm -rf .git
rm -rf hotel-forecast/.git

# Initialiser un nouveau repository
git init

# Ajouter les fichiers (sans node_modules)
git add .
git commit -m "Initial commit - Hotel Forecast app"
```

### 3. Créer le repository GitHub
1. Aller sur https://github.com
2. Cliquer sur "New repository"
3. Nom : `hotel-forecast` ou `hotel-previsions`
4. Description : "Application de prévisions hôtelières avec Next.js et Supabase"
5. **Ne pas** cocher "Add README" (vous en avez déjà un)
6. Cliquer "Create repository"

### 4. Connecter au repository GitHub
```bash
# Ajouter le remote (remplacer VOTRE_USERNAME)
git remote add origin https://github.com/VOTRE_USERNAME/hotel-forecast.git

# Pousser le code
git branch -M main
git push -u origin main
```

### 5. Déployer sur Vercel
1. Aller sur https://vercel.com
2. Se connecter avec votre compte GitHub
3. Cliquer "New Project"
4. Sélectionner votre repository `hotel-forecast`
5. Cliquer "Import"

### 6. Configurer les variables d'environnement dans Vercel
Dans Vercel Dashboard > Project Settings > Environment Variables, ajouter :

```
NEXT_PUBLIC_SUPABASE_URL = https://eihrmhpetbjpeosgtxck.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVpaHJtaHBldGJqcGVvc2d0eGNrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcwODIwNTYsImV4cCI6MjA3MjY1ODA1Nn0.mM1pNb_a8laObxEQAr2Cem0NTWNPj-Xt7m1Z-89OP_I
NODE_ENV = production
```

### 7. Déployer
1. Cliquer "Deploy" dans Vercel
2. Attendre 2-3 minutes
3. Votre app sera disponible sur une URL comme : `https://hotel-forecast-xxx.vercel.app`

## 🔧 Configuration avancée (optionnel)

### Root Directory
Si Vercel ne trouve pas votre app Next.js :
- Dans Project Settings > General
- Root Directory : `hotel-forecast`

### Build Command
- Build Command : `npm run build`
- Output Directory : `.next`

## ✅ Vérification
Une fois déployé, testez :
1. L'URL de votre app fonctionne
2. L'authentification Supabase fonctionne
3. Les données s'affichent correctement

## 🆘 En cas de problème
- Vérifier les logs dans Vercel Dashboard > Functions
- Vérifier que les variables d'environnement sont bien configurées
- Vérifier que Supabase accepte les requêtes depuis votre domaine Vercel

---
**Temps estimé : 10-15 minutes sur un ordinateur fonctionnel ! 🚀**
