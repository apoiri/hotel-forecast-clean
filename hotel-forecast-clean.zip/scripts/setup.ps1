# Script de configuration rapide pour Hôtel Forecast (Windows)
Write-Host "🏨 Configuration de Hôtel Forecast..." -ForegroundColor Green

# Vérifier Node.js
try {
    $nodeVersion = node --version
    Write-Host "✅ Node.js détecté: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Node.js n'est pas installé. Veuillez installer Node.js 18+" -ForegroundColor Red
    exit 1
}

# Vérifier npm
try {
    $npmVersion = npm --version
    Write-Host "✅ npm détecté: $npmVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ npm n'est pas installé" -ForegroundColor Red
    exit 1
}

# Installer les dépendances
Write-Host "📦 Installation des dépendances..." -ForegroundColor Yellow
npm install

# Vérifier si .env.local existe
if (-not (Test-Path ".env.local")) {
    Write-Host "⚠️  Fichier .env.local non trouvé" -ForegroundColor Yellow
    Write-Host "📝 Création du fichier .env.local..." -ForegroundColor Yellow
    Copy-Item "env.example" ".env.local"
    Write-Host "🔧 Veuillez configurer vos clés Supabase dans .env.local" -ForegroundColor Cyan
    Write-Host "   - NEXT_PUBLIC_SUPABASE_URL" -ForegroundColor Cyan
    Write-Host "   - NEXT_PUBLIC_SUPABASE_ANON_KEY" -ForegroundColor Cyan
    Write-Host "   - SUPABASE_SERVICE_ROLE_KEY" -ForegroundColor Cyan
}

# Vérifier si Supabase CLI est installé
try {
    $supabaseVersion = supabase --version
    Write-Host "✅ Supabase CLI détecté: $supabaseVersion" -ForegroundColor Green
} catch {
    Write-Host "⚠️  Supabase CLI n'est pas installé" -ForegroundColor Yellow
    Write-Host "📦 Installation de Supabase CLI..." -ForegroundColor Yellow
    npm install -g supabase
}

Write-Host "✅ Configuration terminée !" -ForegroundColor Green
Write-Host ""
Write-Host "🚀 Prochaines étapes :" -ForegroundColor Cyan
Write-Host "1. Configurer vos clés Supabase dans .env.local" -ForegroundColor White
Write-Host "2. Lier votre projet : npx supabase link --project-ref YOUR_PROJECT_REF" -ForegroundColor White
Write-Host "3. Appliquer les migrations : npx supabase db push" -ForegroundColor White
Write-Host "4. Exécuter le seed : npx supabase db seed" -ForegroundColor White
Write-Host "5. Déployer les Edge Functions : npx supabase functions deploy" -ForegroundColor White
Write-Host "6. Lancer l'application : npm run dev" -ForegroundColor White
Write-Host ""
Write-Host "📚 Consultez le README.md pour plus de détails" -ForegroundColor Cyan

