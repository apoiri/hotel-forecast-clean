#!/bin/bash

# Script de configuration rapide pour Hôtel Forecast
echo "🏨 Configuration de Hôtel Forecast..."

# Vérifier Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js n'est pas installé. Veuillez installer Node.js 18+"
    exit 1
fi

# Vérifier npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm n'est pas installé"
    exit 1
fi

echo "✅ Node.js et npm détectés"

# Installer les dépendances
echo "📦 Installation des dépendances..."
npm install

# Vérifier si .env.local existe
if [ ! -f .env.local ]; then
    echo "⚠️  Fichier .env.local non trouvé"
    echo "📝 Création du fichier .env.local..."
    cp env.example .env.local
    echo "🔧 Veuillez configurer vos clés Supabase dans .env.local"
    echo "   - NEXT_PUBLIC_SUPABASE_URL"
    echo "   - NEXT_PUBLIC_SUPABASE_ANON_KEY"
    echo "   - SUPABASE_SERVICE_ROLE_KEY"
fi

# Vérifier si Supabase CLI est installé
if ! command -v supabase &> /dev/null; then
    echo "⚠️  Supabase CLI n'est pas installé"
    echo "📦 Installation de Supabase CLI..."
    npm install -g supabase
fi

echo "✅ Configuration terminée !"
echo ""
echo "🚀 Prochaines étapes :"
echo "1. Configurer vos clés Supabase dans .env.local"
echo "2. Lier votre projet : npx supabase link --project-ref YOUR_PROJECT_REF"
echo "3. Appliquer les migrations : npx supabase db push"
echo "4. Exécuter le seed : npx supabase db seed"
echo "5. Déployer les Edge Functions : npx supabase functions deploy"
echo "6. Lancer l'application : npm run dev"
echo ""
echo "📚 Consultez le README.md pour plus de détails"

