# Guide de déploiement - Hôtel Forecast

## 🚀 Déploiement rapide

### 1. Préparation Supabase

```bash
# 1. Créer un projet Supabase
# Aller sur https://supabase.com et créer un nouveau projet

# 2. Cloner et installer
git clone <repository-url>
cd hotel-forecast
npm install

# 3. Configurer les variables d'environnement
cp env.example .env.local
# Éditer .env.local avec vos clés Supabase
```

### 2. Configuration de la base de données

```bash
# Lier au projet Supabase
npx supabase link --project-ref YOUR_PROJECT_REF

# Appliquer les migrations
npx supabase db push

# Exécuter le seed
npx supabase db seed

# Déployer les Edge Functions
npx supabase functions deploy compute_forecast
npx supabase functions deploy export_forecast_csv
```

### 3. Configuration Storage

Dans le dashboard Supabase :
1. Aller dans **Storage**
2. Créer un bucket nommé `exports`
3. Configurer les politiques RLS :

```sql
-- Politique pour le bucket exports
CREATE POLICY "Users can upload exports" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'exports');

CREATE POLICY "Users can view their exports" ON storage.objects
FOR SELECT USING (bucket_id = 'exports');
```

### 4. Configuration initiale des données

```sql
-- Dans l'éditeur SQL de Supabase, exécuter :

-- 1. Créer l'organisation
INSERT INTO public.organizations(name) VALUES ('Hotel Edu Org') RETURNING id;

-- 2. Créer l'hôtel (remplacer ORG_ID par l'ID retourné)
INSERT INTO public.hotels(org_id, name, city, rooms_total) 
VALUES ('ORG_ID', 'Hôtel de la Promenade', 'Ottawa', 100) RETURNING id;

-- 3. Créer le profil admin (remplacer USER_ID et HOTEL_ID)
INSERT INTO public.profiles(user_id, org_id, hotel_id, role) 
VALUES ('USER_ID', 'ORG_ID', 'HOTEL_ID', 'admin');
```

### 5. Déploiement Frontend

#### Option A: Vercel (Recommandé)

1. Connecter le repository à Vercel
2. Configurer les variables d'environnement :
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
3. Déployer

#### Option B: Netlify

1. Connecter le repository à Netlify
2. Configurer les variables d'environnement
3. Build command: `npm run build`
4. Publish directory: `.next`

#### Option C: Déploiement manuel

```bash
# Build de production
npm run build

# Démarrer en production
npm start
```

## 🔧 Configuration avancée

### Variables d'environnement

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Optionnel
NEXT_PUBLIC_APP_URL=https://your-domain.com
```

### Configuration des domaines

Dans Supabase Dashboard > Authentication > URL Configuration :
- Site URL: `https://your-domain.com`
- Redirect URLs: `https://your-domain.com/auth/callback`

### Monitoring et logs

1. **Logs Supabase** : Dashboard > Logs
2. **Logs Edge Functions** : Dashboard > Edge Functions
3. **Métriques** : Dashboard > Reports

## 🧪 Tests de déploiement

### 1. Test de l'authentification
```bash
# Vérifier que l'auth fonctionne
curl -X POST https://your-domain.com/auth
```

### 2. Test des Edge Functions
```bash
# Tester compute_forecast
curl -X POST https://your-project.supabase.co/functions/v1/compute_forecast \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"hotelId":"HOTEL_ID","scenarioId":"SCENARIO_ID","year":2025}'
```

### 3. Test de la base de données
```sql
-- Vérifier que les données sont présentes
SELECT COUNT(*) FROM public.organizations;
SELECT COUNT(*) FROM public.hotels;
SELECT COUNT(*) FROM public.segments;
```

## 🚨 Dépannage

### Problèmes courants

1. **Erreur CORS** : Vérifier les domaines autorisés dans Supabase
2. **RLS bloqué** : Vérifier les politiques de sécurité
3. **Edge Functions non trouvées** : Redéployer les fonctions
4. **Storage inaccessible** : Vérifier les politiques du bucket

### Logs utiles

```bash
# Logs de l'application
npm run dev

# Logs Supabase
npx supabase logs

# Logs des Edge Functions
npx supabase functions logs compute_forecast
```

## 📊 Monitoring post-déploiement

### Métriques importantes
- Temps de réponse des API
- Utilisation des Edge Functions
- Erreurs d'authentification
- Performance des requêtes DB

### Alertes recommandées
- Taux d'erreur > 5%
- Temps de réponse > 2s
- Utilisation DB > 80%

## 🔄 Mises à jour

### Mise à jour du code
```bash
git pull origin main
npm install
npm run build
# Redéployer selon votre plateforme
```

### Mise à jour de la DB
```bash
npx supabase db push
```

### Mise à jour des Edge Functions
```bash
npx supabase functions deploy
```

---

**Le déploiement est maintenant terminé ! 🎉**

Votre application Hôtel Forecast est prête à être utilisée.

