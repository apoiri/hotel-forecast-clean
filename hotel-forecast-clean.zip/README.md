# Hôtel Forecast - Application de prévision de ventes

Application web complète pour la prévision de ventes d'un hôtel fictif situé à Ottawa. L'application permet de gérer les paramètres de base, créer des scénarios de prévision, et analyser les résultats avec des graphiques interactifs.

## 🚀 Fonctionnalités

### Dashboard principal
- **KPI en temps réel** : Revenus totaux, taux d'occupation moyen, ADR moyen, RevPAR moyen
- **Graphiques interactifs** : Évolution mensuelle des revenus, répartition par origine clientèle
- **Sélection de scénarios** : Comparaison facile entre différents scénarios

### Gestion des paramètres
- **Baselines** : Configuration des taux d'occupation et ADR de référence par mois
- **Saisonnalité** : Coefficients d'ajustement saisonnier pour occupation et ADR
- **Types de chambres** : Gestion des différents types avec prix de base et capacités
- **Événements** : Configuration d'événements spéciaux avec impact sur la demande

### Scénarios de prévision
- **Création de scénarios** : Ajustements globaux (occupation, ADR, chambres bloquées)
- **Calcul automatique** : Prévisions mensuelles basées sur les paramètres configurés
- **Comparaison** : Analyse comparative entre scénarios

### Export et analyse
- **Export CSV** : Données de prévision exportables pour analyse externe
- **Sécurité** : Authentification et autorisation basées sur les rôles

## 🛠️ Stack technique

### Frontend
- **Next.js 14** avec App Router
- **TypeScript** pour la sécurité des types
- **Tailwind CSS** pour le styling
- **shadcn/ui** pour les composants UI
- **Recharts** pour les graphiques
- **TanStack Query** pour la gestion d'état
- **React Hook Form** + **Zod** pour les formulaires

### Backend
- **Supabase** (PostgreSQL + PostgREST + Auth + Storage)
- **Edge Functions** (Deno) pour les calculs de prévision
- **Row Level Security (RLS)** pour la sécurité des données

### Sécurité
- Authentification par email (magic link)
- Rôles utilisateur (admin, manager, analyst, student)
- RLS "deny-by-default" sur toutes les tables
- Validation stricte côté client et serveur

## 📋 Prérequis

- Node.js 18+ 
- npm ou yarn
- Compte Supabase
- Git

## 🚀 Installation

### 1. Cloner le projet
```bash
git clone <repository-url>
cd hotel-forecast
```

### 2. Installer les dépendances
```bash
npm install
```

### 3. Configuration Supabase

#### Créer un projet Supabase
1. Aller sur [supabase.com](https://supabase.com)
2. Créer un nouveau projet
3. Noter l'URL et les clés API

#### Configurer les variables d'environnement
Créer un fichier `.env.local` :
```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url_here
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key_here
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key_here
```

#### Appliquer les migrations
```bash
# Initialiser Supabase CLI (si pas déjà fait)
npx supabase init

# Lier au projet distant
npx supabase link --project-ref your_project_ref

# Appliquer les migrations
npx supabase db push

# Exécuter le seed
npx supabase db seed
```

#### Déployer les Edge Functions
```bash
# Déployer compute_forecast
npx supabase functions deploy compute_forecast

# Déployer export_forecast_csv
npx supabase functions deploy export_forecast_csv
```

#### Créer le bucket Storage
Dans le dashboard Supabase :
1. Aller dans Storage
2. Créer un bucket nommé `exports`
3. Configurer les politiques RLS pour le bucket

### 4. Lancer l'application
```bash
npm run dev
```

L'application sera disponible sur [http://localhost:3000](http://localhost:3000)

## 📊 Configuration initiale

### 1. Créer un utilisateur admin
1. Aller sur `/auth`
2. Se connecter avec un email
3. Dans le dashboard Supabase, aller dans Authentication > Users
4. Trouver votre utilisateur et noter l'ID

### 2. Configurer l'organisation et l'hôtel
Exécuter ces requêtes SQL dans l'éditeur SQL de Supabase :

```sql
-- Remplacer 'YOUR_USER_ID' par l'ID de votre utilisateur
-- Remplacer 'YOUR_ORG_ID' et 'YOUR_HOTEL_ID' par les IDs générés

-- Créer l'organisation
INSERT INTO public.organizations(name) VALUES ('Hotel Edu Org') RETURNING id;

-- Créer l'hôtel (remplacer 'ORG_ID' par l'ID retourné)
INSERT INTO public.hotels(org_id, name, city, rooms_total) 
VALUES ('ORG_ID', 'Hôtel de la Promenade', 'Ottawa', 100) RETURNING id;

-- Créer le profil admin (remplacer les IDs)
INSERT INTO public.profiles(user_id, org_id, hotel_id, role) 
VALUES ('YOUR_USER_ID', 'ORG_ID', 'HOTEL_ID', 'admin');
```

### 3. Configurer les données de base
Le seed SQL a déjà créé :
- Segments de clientèle (CAN_FR, CAN_EN, USA, EUR, etc.)
- Baselines d'occupation et ADR pour 2025
- Types de chambres avec prix de base
- Événements de démonstration
- Scénario de base

## 🎯 Utilisation

### 1. Dashboard
- Consulter les KPI globaux
- Sélectionner un scénario et une année
- Analyser les graphiques de performance

### 2. Paramètres
- **Baselines** : Ajuster les taux d'occupation et ADR de référence
- **Saisonnalité** : Modifier les coefficients saisonniers
- **Types de chambres** : Gérer les types et leurs prix
- **Événements** : Configurer les événements spéciaux

### 3. Scénarios
- Créer de nouveaux scénarios avec des ajustements
- Calculer les prévisions
- Comparer les résultats

### 4. Export
- Exporter les données en CSV
- Analyser les résultats dans Excel ou autres outils

## 🔒 Sécurité

### Rôles utilisateur
- **admin** : Accès complet à tous les paramètres
- **manager** : Accès complet sauf gestion des rôles
- **analyst** : Création de scénarios, lecture des paramètres
- **student** : Lecture seule, scénarios privés

### RLS (Row Level Security)
- Toutes les tables sont protégées par RLS
- Accès restreint par hôtel et rôle
- Audit log des actions sensibles

## 🧪 Tests

```bash
# Lancer les tests
npm run test

# Tests avec couverture
npm run test:coverage

# Linter
npm run lint

# Vérification des types
npm run type-check
```

## 🚀 Déploiement

### Vercel (recommandé)
1. Connecter le repository à Vercel
2. Configurer les variables d'environnement
3. Déployer automatiquement

### Autres plateformes
L'application est compatible avec toute plateforme supportant Next.js :
- Netlify
- Railway
- DigitalOcean App Platform
- AWS Amplify

## 📈 Monitoring

### Logs
- Logs d'application dans la console
- Logs Supabase dans le dashboard
- Logs Edge Functions dans Supabase

### Métriques
- Performance des requêtes Supabase
- Utilisation des Edge Functions
- Erreurs et exceptions

## 🤝 Contribution

1. Fork le projet
2. Créer une branche feature (`git checkout -b feature/AmazingFeature`)
3. Commit les changements (`git commit -m 'Add some AmazingFeature'`)
4. Push vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrir une Pull Request

## 📝 Licence

Ce projet est sous licence MIT. Voir le fichier `LICENSE` pour plus de détails.

## 🆘 Support

Pour toute question ou problème :
1. Vérifier la documentation Supabase
2. Consulter les issues GitHub
3. Créer une nouvelle issue si nécessaire

## 🔄 Mises à jour

### Migrations de base de données
```bash
# Créer une nouvelle migration
npx supabase migration new migration_name

# Appliquer les migrations
npx supabase db push
```

### Mise à jour des Edge Functions
```bash
# Redéployer les fonctions
npx supabase functions deploy function_name
```

---

**Développé avec ❤️ pour l'éducation en gestion hôtelière**

